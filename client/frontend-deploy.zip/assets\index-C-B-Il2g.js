var m=Object.defineProperty;var n=(a,t)=>m(a,"name",{value:t,configurable:!0});function e(a,[t,c]){return Math.min(c,Math.max(t,a))}n(e,"clamp");export{e as c};
//# sourceMappingURL=index-C-B-Il2g.js.map
