import{d as c}from"./index-BSVp3Gue.js";const o=c("Check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);export{o as C};
//# sourceMappingURL=check-DbtBHZZG.js.map
