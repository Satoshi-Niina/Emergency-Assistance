import{d as e}from"./index-BSVp3Gue.js";const r=e("LoaderCircle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]]);export{r as L};
//# sourceMappingURL=loader-circle-B97NIkBF.js.map
