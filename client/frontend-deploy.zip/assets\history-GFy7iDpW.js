var ts=Object.defineProperty;var i=(l,k)=>ts(l,"name",{value:k,configurable:!0});import{d as Ne,r as g,j as e,B as f,X as ns,M as is,F as Q,g as de}from"./index-BSVp3Gue.js";import{C as O,a as F,b as U,c as H}from"./card-DySZ6HWZ.js";import{I as w}from"./input-D9jzRQeq.js";import{S as se,a as ae,b as te,c as ne,d as $}from"./select-B-e_HbHt.js";import{e as ls,a as cs}from"./history-api-BvcMocqb.js";import{T as _e}from"./textarea-CmvYTv7H.js";import{B as rs}from"./badge-c2QdV__2.js";import{S as os}from"./square-pen-BGAl4--1.js";import{D as X,S as Oe}from"./search-Cb0a0UyV.js";import{S as ds}from"./save-DjOewADo.js";import{I as me}from"./image-BoB9UQtz.js";import"./index-C-B-Il2g.js";import"./index-95KhsQbA.js";import"./index-26QAjfo0.js";import"./check-DbtBHZZG.js";const Ue=Ne("Calendar",[["path",{d:"M8 2v4",key:"1cmpym"}],["path",{d:"M16 2v4",key:"4m81vk"}],["rect",{width:"18",height:"18",x:"3",y:"4",rx:"2",key:"1hopcy"}],["path",{d:"M3 10h18",key:"8toen8"}]]);const Fe=Ne("MapPin",[["path",{d:"M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",key:"1r0f0z"}],["circle",{cx:"12",cy:"10",r:"3",key:"ilqhr7"}]]);const He=Ne("Printer",[["path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",key:"143wyd"}],["path",{d:"M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",key:"1itne7"}],["rect",{x:"6",y:"14",width:"12",height:"8",rx:"1",key:"1ue0tg"}]]),ms="https://emergency-backend-app.azurewebsites.net",ye=i(l=>l?/^data:image\//.test(l)||/^https?:\/\//i.test(l)?l:l.startsWith("/api/")?ms+l:new URL(l,window.location.origin).toString():null,"toAbsUrl"),hs=i(l=>{const k=[l];for(;k.length;){const b=k.pop();if(b!=null){if(typeof b=="string"&&b.startsWith("data:image/"))return b;if(Array.isArray(b))for(const _ of b)k.push(_);else if(typeof b=="object")for(const _ of Object.values(b))k.push(_)}}const I=l?.savedImages?.[0],R=ye(I?.url||I?.path);if(R)return R;const G=l?.imagePath;return(Array.isArray(G)?ye(G[0]):ye(G))||null},"getImageSrc"),ps=i(({data:l,fileName:k,onClose:I,onSave:R,onPrint:G})=>{const[D,b]=g.useState(!1),[_,Z]=g.useState(!1),[u,q]=g.useState({reportId:`R${l.chatId.slice(-5).toUpperCase()}`,machineId:l.machineNumber||l.chatData?.machineInfo?.machineNumber||"M98765",machineType:l.machineType||l.chatData?.machineInfo?.machineTypeName||"",machineNumber:l.machineNumber||l.chatData?.machineInfo?.machineNumber||"",date:new Date(l.exportTimestamp).toISOString().split("T")[0],location:"○○線",failureCode:"FC01",description:l.problemDescription||"チャットによる故障相談・応急処置",status:"応急処置完了",engineer:l.userId||"担当者",notes:`チャットID: ${l.chatId}
メッセージ数: ${l.metadata?.total_messages||l.chatData?.messages?.length||0}件
エクスポート種別: ${l.exportType}`,repairSchedule:"2025年9月",repairLocation:"工場内修理スペース",incidentTitle:l.title||"タイトルなし",problemDescription:l.problemDescription||"説明なし",extractedComponents:l.extractedComponents||[],extractedSymptoms:l.extractedSymptoms||[],possibleModels:l.possibleModels||[]}),[E,T]=g.useState(u);g.useEffect(()=>{T(u)},[u]);const M=i(()=>{const t=[],j={reportId:"報告書ID",machineId:"機械ID",machineType:"機種",machineNumber:"機械番号",date:"日付",location:"場所",failureCode:"故障コード",description:"説明",status:"ステータス",engineer:"担当エンジニア",notes:"備考",repairSchedule:"修繕予定",repairLocation:"修繕場所",incidentTitle:"事象タイトル",problemDescription:"事象説明",extractedComponents:"影響コンポーネント",extractedSymptoms:"症状",possibleModels:"可能性のある機種"};return Object.keys(u).forEach(y=>{const A=u[y],B=E[y];A!==B&&t.push({field:j[y]||y,oldValue:String(A||"未設定"),newValue:String(B||"未設定")})}),t},"calculateDiff")(),he=i(()=>{b(!0)},"handleEdit"),K=i(()=>{q(E),b(!1),Z(!1),l.chatId&&ee(E),R&&R(E);const t=[];l.machineType!==E.machineType&&t.push(`機種: ${l.machineType||"未設定"} → ${E.machineType||"未設定"}`),l.machineNumber!==E.machineNumber&&t.push(`機械番号: ${l.machineNumber||"未設定"} → ${E.machineNumber||"未設定"}`),t.length>0?alert(`レポートが保存されました。

更新された内容:
${t.join(`
`)}`):alert("レポートが保存されました。")},"handleSave"),ee=i(async t=>{try{const j={updatedData:{title:t.incidentTitle,problemDescription:t.problemDescription,machineType:t.machineType||l.machineType||"",machineNumber:t.machineNumber||l.machineNumber||"",extractedComponents:t.extractedComponents,extractedSymptoms:t.extractedSymptoms,possibleModels:t.possibleModels,reportData:t,lastUpdated:new Date().toISOString()},updatedBy:"user"};console.log("📤 サーバーに送信する更新データ:",j),console.log("🔍 機種・機械番号の更新確認:",{machineType:`${l.machineType||"未設定"} → ${t.machineType||"未設定"}`,machineNumber:`${l.machineNumber||"未設定"} → ${t.machineNumber||"未設定"}`});const y=await fetch(`/api/history/update-item/${l.chatId}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(j)});if(!y.ok){const B=await y.json();throw new Error(B.error||"レポートの更新に失敗しました")}const A=await y.json();console.log("✅ レポート更新完了:",A),(l.machineType!==t.machineType||l.machineNumber!==t.machineNumber)&&console.log("🔄 機種・機械番号が更新されました:",{machineType:`${l.machineType||"未設定"} → ${t.machineType||"未設定"}`,machineNumber:`${l.machineNumber||"未設定"} → ${t.machineNumber||"未設定"}`})}catch(j){console.error("❌ レポート更新エラー:",j)}},"updateReportOnServer"),J=i(()=>{window.confirm("編集内容を破棄しますか？")&&(T(u),b(!1),Z(!1))},"handleCancel"),v=i((t,j)=>{T(y=>({...y,[t]:j}))},"handleInputChange"),ve=i((t,j)=>{const y=j?`<div class="image-section">
           <h3>故障箇所画像</h3>
           <img class="report-img" src="${j}" alt="故障画像" />
         </div>`:"";return`
      <!doctype html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>チャットエクスポート報告書印刷</title>
        <style>
          @page { size: A4 portrait; margin: 10mm; }
          @media print {
            html, body { margin: 0; padding: 0; }
            .no-print, .print:hidden { display: none !important; }
            img, .image-cell, .image-section { page-break-inside: avoid; break-inside: avoid; }
            table { width: 100%; border-collapse: collapse; table-layout: fixed; }
            th, td { border: 1px solid #ccc; padding: 4px; vertical-align: top; }
          }
          img.thumb { width: 32px; height: 32px; object-fit: cover; border: 1px solid #ddd; border-radius: 4px; }
          .report-img { max-width: 100%; height: auto; }
        </style>
      </head>
      <body>
        <h1>チャットエクスポート報告書</h1>

        <div class="report-section">
          <h3>基本情報</h3>
          <table>
            <tr><th>報告書ID</th><td>${t.reportId||"-"}</td></tr>
            <tr><th>機械ID</th><td>${t.machineId||"-"}</td></tr>
            <tr><th>機種</th><td>${t.machineType||"-"}</td></tr>
            <tr><th>機械番号</th><td>${t.machineNumber||"-"}</td></tr>
            <tr><th>日付</th><td>${t.date||"-"}</td></tr>
            <tr><th>場所</th><td>${t.location||"-"}</td></tr>
          </table>
        </div>

        <div class="report-section">
          <h3>事象詳細</h3>
          <table>
            <tr><th>事象タイトル</th><td>${t.incidentTitle||"-"}</td></tr>
            <tr><th>事象説明</th><td>${t.problemDescription||"-"}</td></tr>
            <tr><th>故障コード</th><td>${t.failureCode||"-"}</td></tr>
            <tr><th>ステータス</th><td>${t.status||"-"}</td></tr>
            <tr><th>担当エンジニア</th><td>${t.engineer||"-"}</td></tr>
          </table>
        </div>

        <div class="report-section">
          <h3>抽出情報</h3>
          <table>
            <tr><th>影響コンポーネント</th><td>${Array.isArray(t.extractedComponents)?t.extractedComponents.join(", "):"-"}</td></tr>
            <tr><th>症状</th><td>${Array.isArray(t.extractedSymptoms)?t.extractedSymptoms.join(", "):"-"}</td></tr>
            <tr><th>可能性のある機種</th><td>${Array.isArray(t.possibleModels)?t.possibleModels.join(", "):"-"}</td></tr>
          </table>
        </div>

        ${y}

        <div class="report-section">
          <h3>備考</h3>
          <p>${t.notes||"-"}</p>
        </div>

        <div class="report-section">
          <h3>修繕予定</h3>
          <table>
            <tr><th>予定月日</th><td>${t.repairSchedule||"-"}</td></tr>
            <tr><th>場所</th><td>${t.repairLocation||"-"}</td></tr>
          </table>
        </div>
      </body>
      </html>
    `},"generateReportPrintHTML"),pe=i((t,j)=>{const y=window.open("","_blank","noopener,noreferrer");if(!y)return;const A=ve(t,j);y.document.write(A),y.document.close(),setTimeout(()=>{y.print()},100)},"printReport"),o=i(t=>new Date(t).toLocaleString("ja-JP"),"formatDate"),C=i(t=>t&&t.startsWith("data:image/"),"isImageMessage"),P=i(()=>{const t=`
 報告書

事象概要:
事象タイトル: ${u.incidentTitle}
報告書ID: ${u.reportId}
機械ID: ${u.machineId}
日付: ${u.date}
場所: ${u.location}
故障コード: ${u.failureCode}

事象詳細:
説明: ${u.problemDescription}
ステータス: ${u.status}
担当エンジニア: ${u.engineer}
備考: ${u.notes}

抽出情報:
影響コンポーネント: ${u.extractedComponents.join(", ")}
症状: ${u.extractedSymptoms.join(", ")}
可能性のある機種: ${u.possibleModels.join(", ")}

修繕予定:
予定月日: ${u.repairSchedule}
場所: ${u.repairLocation}

チャット履歴:
${(l.conversationHistory||l.chatData?.messages||[]).map(B=>`${B.isAiResponse?"AI":"ユーザー"}: ${B.content}`).join(`
`)}
    `,j=new Blob([t],{type:"text/plain;charset=utf-8"}),y=window.URL.createObjectURL(j),A=document.createElement("a");A.href=y,A.download=`報告書_${u.incidentTitle}_${u.date}.txt`,document.body.appendChild(A),A.click(),document.body.removeChild(A),window.URL.revokeObjectURL(y)},"downloadReport"),S=E,W=hs(l);return console.log("[chat-export] final imgSrc:",W&&W.slice(0,60)),e.jsx("div",{className:"min-h-screen bg-gray-50 p-4",children:e.jsxs("div",{className:"max-w-4xl mx-auto",children:[e.jsxs("div",{className:"flex justify-between items-center mb-6",children:[e.jsx("h1",{className:"text-3xl font-bold text-center flex-1",children:"報告書"}),e.jsx("div",{className:"flex gap-2",children:D?e.jsxs(e.Fragment,{children:[e.jsxs(f,{onClick:K,className:"flex items-center gap-2",children:[e.jsx(ds,{className:"h-4 w-4"}),"保存"]}),e.jsxs(f,{onClick:J,variant:"outline",className:"flex items-center gap-2",children:[e.jsx(ns,{className:"h-4 w-4"}),"キャンセル"]}),e.jsx(f,{onClick:I,variant:"outline",children:"閉じる"})]}):e.jsxs(e.Fragment,{children:[e.jsxs(f,{onClick:he,variant:"outline",className:"flex items-center gap-2",children:[e.jsx(os,{className:"h-4 w-4"}),"レポート編集"]}),M.length>0&&e.jsx(f,{onClick:i(()=>Z(!_),"onClick"),variant:"outline",className:"flex items-center gap-2",children:e.jsxs("span",{className:"text-sm",children:["差分表示 (",M.length,")"]})}),e.jsxs(f,{onClick:i(()=>{pe(S,W)},"onClick"),variant:"outline",className:"flex items-center gap-2",children:[e.jsx(He,{className:"h-4 w-4"}),"印刷"]}),e.jsxs(f,{onClick:P,variant:"outline",className:"flex items-center gap-2",children:[e.jsx(X,{className:"h-4 w-4"}),"ダウンロード"]}),e.jsx(f,{onClick:I,variant:"outline",children:"閉じる"})]})})]}),_&&M.length>0&&e.jsxs(O,{className:"mb-6 border-orange-200 bg-orange-50",children:[e.jsx(F,{children:e.jsx(U,{className:"text-lg font-semibold text-orange-800 flex items-center gap-2",children:e.jsxs("span",{children:["📝 編集内容の差分 (",M.length,"件)"]})})}),e.jsxs(H,{children:[e.jsx("div",{className:"space-y-3",children:M.map((t,j)=>e.jsxs("div",{className:"flex items-center gap-4 p-3 bg-white rounded-lg border",children:[e.jsx("div",{className:"flex-1",children:e.jsxs("span",{className:"font-medium text-gray-700",children:[t.field,":"]})}),e.jsxs("div",{className:"flex-1 text-right",children:[e.jsx("div",{className:"text-sm text-red-600 line-through",children:t.oldValue}),e.jsx("div",{className:"text-sm text-green-600 font-medium",children:t.newValue})]})]},j))}),e.jsx("div",{className:"mt-4 p-3 bg-blue-100 rounded-lg",children:e.jsx("p",{className:"text-sm text-blue-800",children:"💡 上記の変更内容は保存ボタンを押すまで確定されません。"})})]})]}),e.jsxs(O,{className:"mb-6",children:[e.jsx(F,{children:e.jsx(U,{className:"text-lg font-semibold",children:"事象概要"})}),e.jsxs(H,{className:"space-y-3",children:[e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"事象タイトル:"}),e.jsx(w,{value:S.incidentTitle,onChange:i(t=>v("incidentTitle",t.target.value),"onChange"),className:"mt-1",disabled:!D,placeholder:"発生した事象のタイトル"})]}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{className:"font-medium",children:"報告書ID:"}),e.jsx(w,{value:S.reportId,onChange:i(t=>v("reportId",t.target.value),"onChange"),className:"w-32",disabled:!D})]}),e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{className:"font-medium",children:"機械ID:"}),e.jsx(w,{value:S.machineId,onChange:i(t=>v("machineId",t.target.value),"onChange"),className:"w-32",disabled:!D})]}),e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{className:"font-medium",children:"機種:"}),e.jsx(w,{value:S.machineType,onChange:i(t=>v("machineType",t.target.value),"onChange"),className:"w-32",disabled:!D,placeholder:"機種名"})]}),e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{className:"font-medium",children:"機械番号:"}),e.jsx(w,{value:S.machineNumber,onChange:i(t=>v("machineNumber",t.target.value),"onChange"),className:"w-32",disabled:!D,placeholder:"機械番号"})]}),e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{className:"font-medium",children:"日付:"}),e.jsx(w,{type:"date",value:S.date,onChange:i(t=>v("date",t.target.value),"onChange"),className:"w-32",disabled:!D})]}),e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{className:"font-medium",children:"場所:"}),e.jsx(w,{value:S.location,onChange:i(t=>v("location",t.target.value),"onChange"),className:"w-32",disabled:!D})]})]})]})]}),e.jsxs(O,{className:"mb-6",children:[e.jsx(F,{children:e.jsx(U,{className:"text-lg font-semibold",children:"事象詳細"})}),e.jsxs(H,{className:"space-y-3",children:[e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"事象説明:"}),e.jsx(_e,{value:S.problemDescription,onChange:i(t=>v("problemDescription",t.target.value),"onChange"),className:"mt-1",rows:3,disabled:!D,placeholder:"事象の詳細な説明"})]}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{className:"font-medium",children:"ステータス:"}),e.jsx(w,{value:S.status,onChange:i(t=>v("status",t.target.value),"onChange"),className:"w-48",disabled:!D})]}),e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{className:"font-medium",children:"担当エンジニア:"}),e.jsx(w,{value:S.engineer,onChange:i(t=>v("engineer",t.target.value),"onChange"),className:"w-32",disabled:!D})]})]}),e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"備考:"}),e.jsx(_e,{value:S.notes,onChange:i(t=>v("notes",t.target.value),"onChange"),className:"mt-1",rows:3,disabled:!D})]})]})]}),e.jsxs(O,{className:"mb-6",children:[e.jsx(F,{children:e.jsx(U,{className:"text-lg font-semibold",children:"抽出情報"})}),e.jsxs(H,{className:"space-y-3",children:[e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"影響コンポーネント:"}),e.jsx(w,{value:S.extractedComponents.join(", "),onChange:i(t=>v("extractedComponents",t.target.value.split(", ").filter(j=>j.trim())),"onChange"),className:"mt-1",disabled:!D,placeholder:"エンジン, ブレーキ, 油圧系統"})]}),e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"症状:"}),e.jsx(w,{value:S.extractedSymptoms.join(", "),onChange:i(t=>v("extractedSymptoms",t.target.value.split(", ").filter(j=>j.trim())),"onChange"),className:"mt-1",disabled:!D,placeholder:"エンジン停止, 異音, 油圧漏れ"})]}),e.jsxs("div",{children:[e.jsx("span",{className:"font-medium",children:"可能性のある機種:"}),e.jsx(w,{value:S.possibleModels.join(", "),onChange:i(t=>v("possibleModels",t.target.value.split(", ").filter(j=>j.trim())),"onChange"),className:"mt-1",disabled:!D,placeholder:"MT-100型, MR-400シリーズ"})]})]})]}),e.jsxs(O,{className:"mb-6",children:[e.jsx(F,{children:e.jsx(U,{className:"text-lg font-semibold",children:"修繕予定"})}),e.jsx(H,{children:e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{className:"font-medium",children:"予定月日:"}),e.jsx(w,{value:S.repairSchedule,onChange:i(t=>v("repairSchedule",t.target.value),"onChange"),className:"w-32",disabled:!D})]}),e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{className:"font-medium",children:"場所:"}),e.jsx(w,{value:S.repairLocation,onChange:i(t=>v("repairLocation",t.target.value),"onChange"),className:"w-48",disabled:!D})]})]})})]}),e.jsxs(O,{className:"mb-6",children:[e.jsx(F,{children:e.jsx(U,{className:"text-lg font-semibold",children:"故障箇所画像"})}),e.jsxs(H,{children:[e.jsx("p",{className:"text-sm text-gray-600 mb-4",children:"機械故障箇所の画像"}),W?e.jsx("img",{src:W,alt:"故障箇所画像",style:{maxWidth:"100%",height:"auto",display:"block"},onError:i(t=>{t.currentTarget.style.display="none"},"onError")},W.slice(0,64)):e.jsx("div",{className:"text-center text-gray-500",children:"画像がありません"}),e.jsx("p",{className:"text-sm text-gray-600 mt-4",children:"上記は故障箇所の写真です。"})]})]}),e.jsxs(O,{className:"mb-6",children:[e.jsx(F,{children:e.jsx(U,{className:"text-lg font-semibold",children:"チャット履歴サマリー"})}),e.jsxs(H,{children:[e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-4 mb-4",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(Ue,{className:"h-4 w-4 text-gray-500"}),e.jsxs("span",{children:["エクスポート日時: ",o(l.exportTimestamp)]})]}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(is,{className:"h-4 w-4 text-gray-500"}),e.jsxs("span",{children:["メッセージ数: ",l.metadata?.total_messages||l.chatData?.messages?.length||0,"件"]})]}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(me,{className:"h-4 w-4 text-gray-500"}),e.jsxs("span",{children:["画像数: ",l.savedImages?.length||0,"件"]})]})]}),(l.machineType||l.machineNumber)&&e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4 mb-4 p-3 bg-blue-50 rounded-lg",children:[l.machineType&&e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"font-medium",children:"機種:"}),e.jsx("span",{children:l.machineType})]}),l.machineNumber&&e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx("span",{className:"font-medium",children:"機械番号:"}),e.jsx("span",{children:l.machineNumber})]})]}),e.jsx("div",{className:"max-h-96 overflow-y-auto border rounded-lg p-4 bg-gray-50",children:(l.conversationHistory||l.chatData?.messages||[]).map((t,j)=>e.jsxs("div",{className:`mb-4 p-3 rounded-lg ${t.isAiResponse?"bg-blue-50 ml-4":"bg-gray-100 mr-4"}`,children:[e.jsxs("div",{className:"flex items-start gap-2 mb-2",children:[e.jsx(rs,{variant:t.isAiResponse?"default":"secondary",className:"text-xs",children:t.isAiResponse?"AI":"ユーザー"}),e.jsx("span",{className:"text-xs text-gray-500",children:o(t.timestamp||t.createdAt)})]}),e.jsx("div",{className:"mt-1",children:C(t.content)?e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(me,{className:"h-4 w-4 text-gray-500"}),e.jsx("span",{className:"text-sm text-gray-600",children:"画像メッセージ"})]}):e.jsx("p",{className:"text-sm whitespace-pre-wrap leading-relaxed",children:t.content})})]},t.id||j))})]})]}),e.jsx("div",{className:"text-center text-sm text-gray-500 py-4",children:"© 2025 報告書. All rights reserved."})]})})},"ChatExportReport");var xs=ps;const gs=i(()=>{const[l,k]=g.useState([]),[I,R]=g.useState([]),[G,D]=g.useState(""),[b,_]=g.useState({machineType:"",machineNumber:"",searchText:"",searchDate:""}),[Z,u]=g.useState(!0),[q,E]=g.useState(null),[T,ie]=g.useState(new Set),[M,he]=g.useState(1),[K,ee]=g.useState(1),[J,v]=g.useState(!1),[ve,pe]=g.useState(!1),[o,C]=g.useState(null),[P,S]=g.useState(null),[W,t]=g.useState(!1),[j,y]=g.useState(!1),[A,B]=g.useState(!1),[us,js]=g.useState("table"),[Je,We]=g.useState(!1),[we,Be]=g.useState(null),[De,Ve]=g.useState(""),[Y,xe]=g.useState({machineTypes:[],machines:[]}),[L,qe]=g.useState({machineTypes:[],machineNumbers:[]}),[Te,Se]=g.useState(!1),Ce=i(s=>{if(console.log("正規化前のアイテム:",s),!s.jsonData)return console.log("jsonDataが存在しません"),s;if(s.machineType&&s.machineNumber)return console.log("既に正規化済み:",{machineType:s.machineType,machineNumber:s.machineNumber}),s;const a={...s,machineType:s.machineType||s.jsonData.machineType||"",machineNumber:s.machineNumber||s.jsonData.machineNumber||"",jsonData:{...s.jsonData,title:s.jsonData.title||s.title||"",problemDescription:s.jsonData.problemDescription||"",machineType:s.machineType||s.jsonData.machineType||"",machineNumber:s.machineNumber||s.jsonData.machineNumber||"",extractedComponents:s.jsonData.extractedComponents||s.extractedComponents||[],extractedSymptoms:s.jsonData.extractedSymptoms||s.extractedSymptoms||[],possibleModels:s.jsonData.possibleModels||s.possibleModels||[],conversationHistory:s.jsonData.conversationHistory||[],savedImages:s.jsonData.savedImages||[]}};if(s.jsonData.chatData){console.log("chatData形式を検出");const n=s.jsonData.chatData,r=n.machineInfo?.machineTypeName||"",d=n.machineInfo?.machineNumber||"";console.log("chatDataから抽出:",{machineTypeName:r,machineNumber:d}),a.machineType=r||a.machineType,a.machineNumber=d||a.machineNumber,a.jsonData.machineType=r||a.jsonData.machineType,a.jsonData.machineNumber=d||a.jsonData.machineNumber}return console.log("正規化後のアイテム:",a),a},"normalizeJsonData");g.useEffect(()=>{const s=i(a=>{if(a.data&&a.data.type==="UPDATE_HISTORY_ITEM"){const n=a.data.data;console.log("履歴データ更新メッセージを受信:",n),k(r=>r.map(d=>d.id===n.id||d.chatId===n.chatId?{...d,...n}:d)),R(r=>r.map(d=>d.id===n.id||d.chatId===n.chatId?{...d,...n}:d)),q&&(q.id===n.id||q.chatId===n.chatId)&&E(r=>r?{...r,...n}:null)}},"handleMessage");return window.addEventListener("message",s),()=>window.removeEventListener("message",s)},[q]);const[ge,Ie]=g.useState(!1);g.useEffect(()=>{console.log("🔍 machineData状態変化:",Y)},[Y]),g.useEffect(()=>{const s=i(async()=>{try{console.log("🔍 データ初期化開始"),u(!0),await Promise.all([le().catch(a=>{console.error("履歴データ取得エラー:",a)}),$e().catch(a=>{console.error("機種データ取得エラー:",a)})]),console.log("🔍 データ初期化完了")}catch(a){console.error("データ初期化エラー:",a)}finally{u(!1)}},"initializeData");console.log("🔍 useEffect実行"),s()},[]);const $e=i(async()=>{try{Ie(!0),console.log("🔍 機種・機械番号データ取得開始");const s=await fetch("/api/history/machine-data");console.log("🔍 APIレスポンス:",s.status,s.statusText);const a=await s.json();if(console.log("🔍 APIレスポンスデータ:",a),a.success&&a.machineTypes&&a.machines){const n=new Set,r=[],d=new Set,p=[];console.log("🔍 機種・機械番号データは専用APIから取得されます");const c={machineTypes:a.machineTypes||[],machines:a.machines||[]};console.log("🔍 機種・機械番号データ取得結果:",c),console.log("🔍 機種数:",c.machineTypes.length),console.log("🔍 機械番号数:",c.machines.length),console.log("🔍 機種一覧:",c.machineTypes.map(h=>h.machineTypeName)),console.log("🔍 機械番号一覧:",c.machines.map(h=>`${h.machineNumber} (${h.machineTypeName})`)),console.log("🔍 setMachineData呼び出し前:",c),xe(c),console.log("🔍 setMachineData呼び出し完了")}else console.log("⚠️ 機種・機械番号データが正しく取得できませんでした:",a),console.log("⚠️ data.success:",a.success),console.log("⚠️ data.machineTypes:",a.machineTypes),console.log("⚠️ data.machines:",a.machines),xe({machineTypes:[],machines:[]})}catch(s){console.error("機種・機械番号データの取得に失敗しました:",s),xe({machineTypes:[],machines:[]})}finally{Ie(!1)}},"fetchMachineDataFromAPI"),Ke=i(async()=>{try{Se(!0),console.log("🔍 履歴検索フィルターデータ取得開始");const a=await(await fetch("/api/history/search-filters")).json();a.success?(qe({machineTypes:a.machineTypes||[],machineNumbers:a.machineNumbers||[]}),console.log("🔍 履歴検索フィルターデータ取得完了:",{machineTypes:a.machineTypes?.length||0,machineNumbers:a.machineNumbers?.length||0})):console.error("履歴検索フィルターデータ取得失敗:",a.error)}catch(s){console.error("履歴検索フィルターデータ取得エラー:",s)}finally{Se(!1)}},"fetchSearchFilterData"),le=i(async(s=1)=>{try{u(!0);const a=new URLSearchParams;b.machineType&&a.append("machineType",b.machineType),b.machineNumber&&a.append("machineNumber",b.machineNumber),b.searchText&&a.append("searchText",b.searchText),b.searchDate&&a.append("searchDate",b.searchDate),a.append("limit","20"),a.append("offset",((s-1)*20).toString());const r=await(await fetch(`/api/history?${a.toString()}`)).json();if(console.log("🔍 取得したデータ:",r),r.success&&r.items){console.log("🔍 取得件数:",r.items.length),r.items.forEach((p,c)=>{console.log(`🔍 アイテム ${c+1}:`,{fileName:p.fileName,machineType:p.machineType,machineNumber:p.machineNumber,machineInfo:p.machineInfo})});const d=r.items.map(p=>{const c="savedMachineFailureReport_"+(p.id||p.chatId),h=localStorage.getItem(c);let m=p;if(h)try{const x=JSON.parse(h);console.log("ローカルストレージから保存されたデータを読み込み:",x),m={...p,...x}}catch(x){console.warn("保存されたデータの解析に失敗:",x)}const z={id:m.id,chatId:m.chatId,fileName:m.fileName,machineType:m.machineType||"",machineNumber:m.machineNumber||"",title:m.title,createdAt:m.createdAt||m.exportTimestamp||new Date().toISOString(),lastModified:m.lastModified,extractedComponents:m.extractedComponents,extractedSymptoms:m.extractedSymptoms,possibleModels:m.possibleModels,machineInfo:m.machineInfo,jsonData:{...m,machineType:m.machineType||"",machineNumber:m.machineNumber||"",title:m.title,problemDescription:m.problemDescription,extractedComponents:m.extractedComponents,extractedSymptoms:m.extractedSymptoms,possibleModels:m.possibleModels,conversationHistory:m.conversationHistory,chatData:m.chatData,savedImages:m.savedImages,metadata:m.metadata}};return console.log("変換されたアイテム:",{fileName:z.fileName,machineType:z.machineType,machineNumber:z.machineNumber,jsonData:z.jsonData}),z});k(d),R(d),ee(Math.ceil(r.total/20)),he(s)}else console.log("🔍 データ取得成功せず:",r),k([]),R([]),ee(1)}catch(a){console.error("履歴データの取得に失敗しました:",a),k([]),R([]),ee(1)}finally{u(!1)}},"fetchHistoryData");g.useEffect(()=>{M===1&&l.length===0&&(le(1),Ke())},[]);const ce=i((s,a)=>{_(n=>({...n,[s]:a}));try{o&&(s==="machineType"||s==="machineNumber")&&(C(n=>n&&{...n,[s]:a}),console.log(`filters -> editingItem sync: ${s} = ${a}`))}catch(n){console.warn("フィルターから編集アイテムへの同期に失敗しました:",n)}},"handleFilterChange"),ke=i(()=>{le(1)},"handleSearch"),ue=i(s=>{le(s)},"handlePageChange"),Ye=i(s=>{ie(a=>{const n=new Set(a);return n.has(s)?n.delete(s):n.add(s),n})},"handleSelectItem"),Qe=i(()=>{T.size===I.length?ie(new Set):ie(new Set(I.map(s=>s.id)))},"handleSelectAll"),Me=i(async(s="json")=>{if(T.size===0){alert("エクスポートする履歴を選択してください。");return}try{v(!0);const a=I.filter(r=>T.has(r.id)),n=await ls(a,s);Pe(n,`selected_history.${s}`)}catch(a){console.error("選択履歴エクスポートエラー:",a)}finally{v(!1)}},"handleExportSelected"),Pe=i((s,a)=>{const n=window.URL.createObjectURL(s),r=document.createElement("a");r.href=n,r.download=a,document.body.appendChild(r),r.click(),window.URL.revokeObjectURL(n),document.body.removeChild(r)},"downloadFile"),Ae=i(async(s="json")=>{try{v(!0);const a=await cs(b,s);Pe(a,`all_history.${s}`)}catch(a){console.error("エクスポートエラー:",a)}finally{v(!1)}},"handleExportAll"),Xe=i(()=>{_({machineType:"",machineNumber:"",searchText:"",searchDate:""})},"clearFilters"),re=i(s=>new Date(s).toLocaleString("ja-JP"),"formatDate"),Ge=i(()=>{We(!1),Be(null),Ve(""),pe(!1)},"handleCloseReport"),Ze=i(s=>{console.log("レポートデータを保存:",s);const a=JSON.parse(localStorage.getItem("savedReports")||"[]"),n={id:Date.now(),fileName:De,reportData:s,savedAt:new Date().toISOString()};a.push(n),localStorage.setItem("savedReports",JSON.stringify(a)),console.log("レポートが保存されました:",n)},"handleSaveReport"),Re=i(async s=>{try{console.log("編集された履歴アイテムを保存:",s),console.log("編集された履歴アイテムのID:",s.id),console.log("編集された履歴アイテムのJSONデータ:",s.jsonData);let a=s.id||s.chatId;if(!a){alert("アイテムIDが見つかりません。保存できません。");return}if(a.startsWith("export_")){a=a.replace("export_",""),a.endsWith(".json")&&(a=a.replace(".json",""));const p=a.split("_");p.length>=2&&p[1].match(/^[a-f0-9-]+$/)&&(a=p[1])}console.log("使用するID:",a,"元のID:",s.id||s.chatId);const n={updatedData:{...s.jsonData,machineType:s.machineType,machineNumber:s.machineNumber,title:s.jsonData?.title||s.title,lastModified:new Date().toISOString()},updatedBy:"user"};console.log("送信するペイロード:",n);const r=await fetch(`/api/history/update-item/${a}`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(n)});if(console.log("サーバーレスポンス:",r.status,r.statusText),!r.ok){const p=await r.text();console.error("サーバーエラー詳細:",p);let c=`履歴の更新に失敗しました (${r.status})`;try{c=JSON.parse(p).error||c}catch{c+=": "+p}alert(c);return}const d=await r.json();if(console.log("履歴更新完了:",d),a){const p="savedMachineFailureReport_"+a;localStorage.setItem(p,JSON.stringify(s.jsonData)),console.log("ローカルストレージ更新:",p)}k(p=>p.map(c=>c.id===a||c.chatId===a?{...c,jsonData:s.jsonData,lastModified:new Date().toISOString(),machineType:s.jsonData?.machineType||c.machineType,machineNumber:s.jsonData?.machineNumber||c.machineNumber,title:s.jsonData?.title||c.title,incidentTitle:s.jsonData?.title||c.incidentTitle}:c)),R(p=>p.map(c=>c.id===a||c.chatId===a?{...c,jsonData:s.jsonData,lastModified:new Date().toISOString(),machineType:s.jsonData?.machineType||c.machineType,machineNumber:s.jsonData?.machineNumber||c.machineNumber,title:s.jsonData?.title||c.title,incidentTitle:s.jsonData?.title||c.incidentTitle}:c)),alert("履歴が正常に更新され、元のファイルに上書き保存されました。"),t(!1),C(null),console.log("履歴更新完了 - リスト再読み込みをスキップ")}catch(a){console.error("履歴保存エラー:",a);const n=a instanceof Error?a.message:"Unknown error";alert("履歴の保存に失敗しました: "+n)}},"handleSaveEditedItem");function je(s){const a=i(d=>{if(!d)return null;if(typeof d=="string"&&d.startsWith("data:image/"))return d;if(Array.isArray(d))for(const p of d){const c=a(p);if(c)return c}if(typeof d=="object")for(const p of Object.keys(d)){const c=a(d[p]);if(c)return c}return null},"dig"),n=a(s);if(n)return n;const r=s?.savedImages;return Array.isArray(r)&&r[0]?r[0]:typeof s?.imagePath=="string"?s.imagePath:null}i(je,"pickFirstImage");const es=i(()=>{const s=window.open("","_blank");if(!s)return;const a=T.size>0?I.filter(r=>T.has(r.id)):I,n=`
      <!DOCTYPE html>
      <html>
      <head>
        <title>履歴一覧 - 印刷</title>
        <style>
          @page { size: A4 portrait; margin: 10mm; }
          @media print {
            html, body { margin: 0; padding: 0; }
            .no-print { display: none !important; }
            img, .image-cell { break-inside: avoid; page-break-inside: avoid; }
            table { width: 100%; border-collapse: collapse; table-layout: fixed; }
            th, td { border: 1px solid #ccc; padding: 4px; vertical-align: top; }
          }
          body { font-family: Arial, sans-serif; margin: 20px; }
          .header { text-align: center; margin-bottom: 20px; }
          .header h1 { margin: 0; color: #333; }
          .header p { margin: 5px 0; color: #666; }
          table { width: 100%; border-collapse: collapse; margin-top: 20px; }
          th, td { border: 1px solid #ddd; padding: 8px; text-align: left; font-size: 12px; vertical-align: top; }
          th { background-color: #f5f5f5; font-weight: bold; }
          .summary { margin-bottom: 20px; padding: 10px; background-color: #f9f9f9; border-radius: 5px; }
          .image-cell img { max-width: 100px; max-height: 100px; object-fit: cover; border: 1px solid #ddd; border-radius: 4px; display: block; margin: 0 auto; }
          .image-cell { text-align: center; vertical-align: middle; }
          img.thumb { width: 32px; height: 32px; object-fit: cover; border: 1px solid #ddd; border-radius: 4px; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>機械故障履歴一覧</h1>
          <p>印刷日時: ${new Date().toLocaleString("ja-JP")}</p>
          <p>対象件数: ${a.length}件${T.size>0?" (選択された履歴)":""}</p>
        </div>
        
        <div class="summary">
          <strong>印刷対象:</strong> ${T.size>0?"選択された履歴":"機械故障履歴一覧"}<br>
          <strong>印刷日時:</strong> ${new Date().toLocaleString("ja-JP")}<br>
          <strong>対象件数:</strong> ${a.length}件
        </div>
        
        <table>
          <thead>
            <tr>
              <th>機種</th>
              <th>機械番号</th>
              <th>事象</th>
              <th>説明</th>
              <th>作成日時</th>
              <th>画像</th>
            </tr>
          </thead>
          <tbody>
            ${a.map(r=>{const d=r.jsonData,p=d?.machineType||d?.originalChatData?.machineInfo?.machineTypeName||d?.chatData?.machineInfo?.machineTypeName||r.machineType||"",c=d?.machineNumber||d?.originalChatData?.machineInfo?.machineNumber||d?.chatData?.machineInfo?.machineNumber||r.machineNumber||"",h=d?.title||d?.question||"事象なし",m=d?.problemDescription||d?.answer||"説明なし",z=je(r);return`
                <tr>
                  <td>${p}</td>
                  <td>${c}</td>
                  <td>${h}</td>
                  <td>${m}</td>
                  <td>${re(r.createdAt)}</td>
                  <td class="image-cell">${z?`<img class="thumb" src="${z}" alt="故障画像" onerror="this.style.display='none'; this.nextSibling.style.display='inline';" /><span style="display:none; color: #999; font-size: 10px;">画像読み込みエラー</span>`:"なし"}</td>
                </tr>
              `}).join("")}
          </tbody>
        </table>
        
        <div class="no-print" style="margin-top: 20px; text-align: center;">
          <button onclick="window.close()">閉じる</button>
        </div>
      </body>
      </html>
    `;s.document.write(n),s.document.close(),setTimeout(()=>{s.print()},100)},"handlePrintTable"),Ee=i(s=>{const a=window.open("","_blank");if(!a)return;const n=s.jsonData;let r="事象なし";if(s.fileName){const x=s.fileName.split("_");x.length>1&&(r=x[0])}if(r==="事象なし"&&(r=n?.title||n?.question||"事象なし",r==="事象なし"&&n?.chatData?.messages)){const x=n.chatData.messages.filter(N=>!N.isAiResponse);x.length>0&&(r=x[0].content||"事象なし")}const d=n?.problemDescription||n?.answer||"説明なし",p=s.machineInfo?.machineTypeName||n?.machineType||n?.chatData?.machineInfo?.machineTypeName||s.machineType||"",c=s.machineInfo?.machineNumber||n?.machineNumber||n?.chatData?.machineInfo?.machineNumber||s.machineNumber||"";n?.extractedComponents,n?.extractedSymptoms,n?.possibleModels;let h="",m="";if(console.log("個別レポート印刷用画像読み込み処理:",{itemId:s.id,hasJsonData:!!n,jsonDataKeys:n?Object.keys(n):[],savedImages:n?.savedImages,conversationHistory:n?.conversationHistory,originalChatData:n?.originalChatData,chatData:n?.chatData,imagePath:s.imagePath}),n?.conversationHistory&&n.conversationHistory.length>0){const x=n.conversationHistory.find(N=>N.content&&N.content.startsWith("data:image/"));x&&(h=x.content,m=`故障画像_${s.id}`,console.log("個別レポート印刷用: conversationHistoryからBase64画像を取得（最優先）"))}if(!h&&n?.originalChatData?.messages){const x=n.originalChatData.messages.find(N=>N.content&&N.content.startsWith("data:image/"));x&&(h=x.content,m=`故障画像_${s.id}`,console.log("個別レポート印刷用: originalChatDataからBase64画像を取得（優先順位2）"))}if(!h&&n?.chatData?.messages){const x=n.chatData.messages.find(N=>N.content&&N.content.startsWith("data:image/"));x&&(h=x.content,m=`故障画像_${s.id}`,console.log("個別レポート印刷用: chatDataからBase64画像を取得（優先順位3）"))}if(!h&&n?.messages&&Array.isArray(n.messages)){const x=n.messages.find(N=>N.content&&N.content.startsWith("data:image/"));x&&(h=x.content,m=`故障画像_${s.id}`,console.log("個別レポート印刷用: messagesフィールドからBase64画像を取得（優先順位4）"))}if(!h&&n?.savedImages&&n.savedImages.length>0){const x=n.savedImages[0];h=x.url||"",m=x.fileName||`故障画像_${s.id}`,console.log("個別レポート印刷用: savedImagesから画像を取得（優先順位5）")}if(!h&&n?.originalChatData?.messages){const x=n.originalChatData.messages.find(N=>N.content&&N.content.startsWith("data:image/"));x&&(h=x.content,m=`故障画像_${s.id}`,console.log("個別レポート印刷用: originalChatDataからBase64画像を取得（優先順位3）"))}if(!h&&n?.chatData?.messages){const x=n.chatData.messages.find(N=>N.content&&N.content.startsWith("data:image/"));x&&(h=x.content,m=`故障画像_${s.id}`,console.log("個別レポート印刷用: chatDataからBase64画像を取得（優先順位4）"))}if(!h){const x=i((fe,Le="")=>{const oe=[];if(fe&&typeof fe=="object")for(const[ze,V]of Object.entries(fe)){const be=Le?`${Le}.${ze}`:ze;typeof V=="string"&&V.startsWith("data:image/")?oe.push({path:be,content:V}):Array.isArray(V)?V.forEach((ss,as)=>{oe.push(...x(ss,`${be}[${as}]`))}):typeof V=="object"&&V!==null&&oe.push(...x(V,be))}return oe},"findImagesRecursively"),N=x(n);N.length>0&&(h=N[0].content,m=`故障画像_${s.id}`,console.log("個別レポート印刷用: 再帰的検索で画像を取得（優先順位6）"))}!h&&s.imagePath&&(h=s.imagePath.startsWith("http")?s.imagePath:s.imagePath.startsWith("/")?`${window.location.origin}${s.imagePath}`:`${window.location.origin}/api/images/chat-exports/${s.imagePath}`,m=`故障画像_${s.id}`,console.log("個別レポート印刷用: imagePathから画像を取得（最終フォールバック）")),console.log("個別レポート印刷用: 最終的な画像情報:",{hasImage:!!h,imageUrl:h?h.substring(0,100)+"...":"なし",imageFileName:m,isBase64:h?h.startsWith("data:image/"):!1});const z=`
      <!DOCTYPE html>
      <html>
      <head>
        <title>機械故障報告書 - 印刷</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
          .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 20px; }
          .header h1 { margin: 0; color: #333; font-size: 24px; }
          .header p { margin: 5px 0; color: #666; }
          .section { margin-bottom: 25px; }
          .section h2 { color: #333; border-bottom: 1px solid #ddd; padding-bottom: 5px; }
          .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
          .info-item { padding: 10px; background-color: #f9f9f9; border-radius: 5px; }
          .info-item strong { display: block; margin-bottom: 5px; color: #333; }
          .content-box { background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin-top: 10px; }
          .image-section { text-align: center; margin: 20px 0; }
          .image-section img { max-width: 100%; max-height: 300px; border: 1px solid #ddd; border-radius: 5px; }
          @media print {
            .no-print { display: none; }
            body { 
              margin: 0; 
              font-size: 10px;
              line-height: 1.2;
            }
            .header h1 { 
              font-size: 16px; 
              margin: 5px 0; 
            }
            .header p { 
              font-size: 8px; 
              margin: 2px 0; 
            }
            .section { 
              margin: 8px 0; 
              page-break-inside: avoid;
            }
            .section h2 { 
              font-size: 12px; 
              margin: 5px 0; 
            }
            .info-grid { 
              gap: 4px; 
            }
            .info-item { 
              font-size: 9px; 
              padding: 2px; 
            }
            .content { 
              font-size: 9px; 
              line-height: 1.1;
            }
            .image-section { 
              margin: 8px 0; 
            }
            .image-section img { 
              max-height: 150px; 
            }
            @page {
              size: A4;
              margin: 10mm;
            }
          }
        </style>
      </head>
      <body>
        <div class="header">
                      <h1>機械故障報告書</h1>
          <p>印刷日時: ${new Date().toLocaleString("ja-JP")}</p>
        </div>
        
        <div class="section">
          <h2>報告概要</h2>
          <div class="info-grid">
            <div class="info-item">
              <strong>報告書ID</strong>
              R${s.id.slice(-5).toUpperCase()}
            </div>
            <div class="info-item">
              <strong>機械ID</strong>
              ${s.machineNumber}
            </div>
            <div class="info-item">
              <strong>日付</strong>
              ${new Date(s.createdAt).toISOString().split("T")[0]}
            </div>
            <div class="info-item">
              <strong>場所</strong>
              ○○線
            </div>
            <div class="info-item">
              <strong>故障コード</strong>
              FC01
            </div>
          </div>
        </div>
        
        <div class="section">
          <h2>事象詳細</h2>
          <div class="content-box">
            <p><strong>事象タイトル:</strong> ${r}</p>
            <p><strong>事象説明:</strong> ${d}</p>
            <p><strong>ステータス:</strong> 応急処置完了</p>
            <p><strong>担当エンジニア:</strong> 担当者</p>
            <p><strong>機種:</strong> ${p}</p>
            <p><strong>機械番号:</strong> ${c}</p>
          </div>
        </div>
        
        ${h?`
        <div class="section">
          <h2>故障箇所画像</h2>
          <div class="image-section">
            <p>機械故障箇所の画像</p>
            <img src="${h}" alt="故障箇所画像" />
            <p style="font-size: 12px; color: #666;">上記は故障箇所の写真です。</p>
          </div>
        </div>
        `:""}
        
        <div class="section">
          <h2>修繕計画</h2>
          <div class="info-grid">
            <div class="info-item">
              <strong>予定月日</strong>
              ${s.jsonData?.repairSchedule||"-"}
            </div>
            <div class="info-item">
              <strong>場所</strong>
              ${s.jsonData?.location||"-"}
            </div>
          </div>
        </div>
        
        <div class="section">
          <h2>記事欄</h2>
          <div class="content-box">
            <p>${s.jsonData?.remarks||"記載なし"}</p>
          </div>
        </div>
        
        <div class="section">
          <p style="text-align: center; color: #666; font-size: 12px;">
            © 2025 機械故障報告書. All rights reserved.
          </p>
        </div>
        
        <div class="no-print" style="margin-top: 30px; text-align: center;">
          <button onclick="window.print()">印刷</button>
          <button onclick="window.close()">閉じる</button>
        </div>
      </body>
      </html>
    `;a.document.write(z),a.document.close()},"handlePrintReport");return Z?e.jsx("div",{className:"p-6",children:e.jsx("div",{className:"flex items-center justify-center h-64",children:e.jsxs("div",{className:"text-center",children:[e.jsx("div",{className:"animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"}),e.jsx("p",{className:"text-gray-600",children:"履歴データを読み込み中..."})]})})}):e.jsxs("div",{className:"p-6 max-w-7xl mx-auto",children:[e.jsxs("div",{className:"mb-6",children:[e.jsx("h1",{className:"text-2xl font-bold mb-2",children:"履歴管理"}),e.jsx("p",{className:"text-gray-600",children:"送信されたデータと関連画像の履歴を管理・検索できます"})]}),e.jsxs(O,{className:"mb-6",children:[e.jsx(F,{children:e.jsxs(U,{className:"flex items-center gap-2",children:[e.jsx(Oe,{className:"h-5 w-5"}),"検索フィルター"]})}),e.jsxs(H,{children:[e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4",children:[e.jsx("div",{className:"lg:col-span-2",children:e.jsxs("div",{className:"space-y-2",children:[e.jsx(w,{placeholder:"タイトル、機種、事業所、応急処置内容、キーワードなどで検索...",value:b.searchText,onChange:i(s=>ce("searchText",s.target.value),"onChange"),onKeyDown:i(s=>{s.key==="Enter"&&ke()},"onKeyDown"),className:"w-full"}),e.jsx("p",{className:"text-xs text-gray-500",children:"※ 複数のキーワードをスペース区切りで入力すると、すべてのキーワードを含む履歴を検索します"})]})}),e.jsx("div",{children:e.jsxs("div",{className:"space-y-2",children:[e.jsx(w,{type:"date",value:b.searchDate,onChange:i(s=>ce("searchDate",s.target.value),"onChange"),className:"w-full"}),e.jsx("p",{className:"text-xs text-gray-500",children:"※ 指定した日付の履歴を検索します"})]})}),e.jsx("div",{children:e.jsxs("div",{className:"space-y-2",children:[e.jsxs(se,{value:b.machineType||"all",onValueChange:i(s=>ce("machineType",s==="all"?"":s),"onValueChange"),children:[e.jsx(ae,{children:e.jsx(te,{placeholder:"機種を選択"})}),e.jsxs(ne,{children:[e.jsx($,{value:"all",children:"すべての機種"}),Te?e.jsx($,{value:"loading",disabled:!0,children:"読み込み中..."}):L.machineTypes&&L.machineTypes.length>0?L.machineTypes.map((s,a)=>e.jsx($,{value:s,children:s},`type-${a}`)):e.jsx($,{value:"no-data",disabled:!0,children:"データがありません"})]})]}),e.jsxs("p",{className:"text-xs text-gray-500",children:["※ JSONファイルから機種を取得しています",L.machineTypes&&` (${L.machineTypes.length}件)`]})]})}),e.jsx("div",{children:e.jsxs("div",{className:"space-y-2",children:[e.jsxs(se,{value:b.machineNumber||"all",onValueChange:i(s=>ce("machineNumber",s==="all"?"":s),"onValueChange"),children:[e.jsx(ae,{children:e.jsx(te,{placeholder:"機械番号を選択"})}),e.jsxs(ne,{children:[e.jsx($,{value:"all",children:"すべての機械番号"}),Te?e.jsx($,{value:"loading",disabled:!0,children:"読み込み中..."}):L.machineNumbers&&L.machineNumbers.length>0?L.machineNumbers.map((s,a)=>e.jsx($,{value:s,children:s},`number-${a}`)):e.jsx($,{value:"no-data",disabled:!0,children:"データがありません"})]})]}),e.jsxs("p",{className:"text-xs text-gray-500",children:["※ JSONファイルから機械番号を取得しています",L.machineNumbers&&` (${L.machineNumbers.length}件)`]})]})})]}),e.jsxs("div",{className:"flex gap-2",children:[e.jsxs(f,{onClick:ke,className:"flex items-center gap-2",children:[e.jsx(Oe,{className:"h-4 w-4"}),"検索"]}),e.jsx(f,{variant:"outline",onClick:Xe,children:"フィルタークリア"})]})]})]}),e.jsxs(O,{className:"mb-6",children:[e.jsx(F,{children:e.jsx(U,{className:"flex items-center justify-between",children:e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(Q,{className:"h-5 w-5"}),"機械故障履歴一覧 (",I.length,"件)"]})})}),e.jsx(H,{children:I.length===0?e.jsxs("div",{className:"text-center py-8",children:[e.jsx(Q,{className:"h-12 w-12 text-gray-400 mx-auto mb-4"}),e.jsx("p",{className:"text-gray-600",children:"履歴データがありません"})]}):e.jsx("div",{className:"space-y-4",children:e.jsx("div",{className:"overflow-x-auto",children:e.jsxs("table",{className:"w-full border-collapse border border-gray-300",children:[e.jsx("thead",{children:e.jsxs("tr",{className:"bg-gray-50",children:[e.jsxs("th",{className:"border border-gray-300 px-3 py-2 text-center text-sm font-medium",children:[e.jsx("input",{type:"checkbox",checked:T.size===I.length&&I.length>0,onChange:Qe,className:"mr-2 w-6 h-6"}),"選択"]}),e.jsx("th",{className:"border border-gray-300 px-3 py-2 text-left text-sm font-medium",children:"機種"}),e.jsx("th",{className:"border border-gray-300 px-3 py-2 text-left text-sm font-medium",children:"機械番号"}),e.jsx("th",{className:"border border-gray-300 px-3 py-2 text-left text-sm font-medium",children:"事象内容"}),e.jsx("th",{className:"border border-gray-300 px-3 py-2 text-left text-sm font-medium",children:"説明/エクスポート種別"}),e.jsx("th",{className:"border border-gray-300 px-3 py-2 text-left text-sm font-medium",children:"作成日時"}),e.jsx("th",{className:"border border-gray-300 px-3 py-2 text-left text-sm font-medium",children:"画像"}),e.jsx("th",{className:"border border-gray-300 px-3 py-2 text-left text-sm font-medium",children:"アクション"})]})}),e.jsx("tbody",{children:I.map(s=>{const a=s.jsonData;let n="事象なし";if(s.fileName){const c=s.fileName.split("_");c.length>1&&(n=c[0])}if(n==="事象なし"&&(n=a?.title||a?.question||"事象なし",n==="事象なし"&&a?.chatData?.messages)){const c=a.chatData.messages.filter(h=>!h.isAiResponse);c.length>0&&(n=c[0].content||"事象なし")}const r=a?.problemDescription||a?.answer||"説明なし",d=a?.machineType||a?.chatData?.machineInfo?.machineTypeName||s.machineInfo?.machineTypeName||s.machineType||"",p=a?.machineNumber||a?.chatData?.machineInfo?.machineNumber||s.machineInfo?.machineNumber||s.machineNumber||"";return console.log(`🔍 アイテム表示: ${s.fileName}`,{machineType:d,machineNumber:p,jsonDataMachineType:a?.machineType,jsonDataMachineNumber:a?.machineNumber,itemMachineType:s.machineType,itemMachineNumber:s.machineNumber}),a?.metadata?.total_messages||a?.chatData?.messages?.length||a?.messageCount,a?.exportType,a?.metadata?.fileName,e.jsxs("tr",{className:"hover:bg-gray-50 bg-blue-50",children:[e.jsx("td",{className:"border border-gray-300 px-3 py-2 text-center text-sm",children:e.jsx("input",{type:"checkbox",checked:T.has(s.id),onChange:i(()=>Ye(s.id),"onChange"),className:"w-6 h-6"})}),e.jsx("td",{className:"border border-gray-300 px-3 py-2 text-sm",children:d||"-"}),e.jsx("td",{className:"border border-gray-300 px-3 py-2 text-sm",children:p||"-"}),e.jsx("td",{className:"border border-gray-300 px-3 py-2 text-sm max-w-xs truncate",title:n,children:n}),e.jsx("td",{className:"border border-gray-300 px-3 py-2 text-sm max-w-xs truncate",title:r,children:r}),e.jsx("td",{className:"border border-gray-300 px-3 py-2 text-sm",children:re(s.createdAt)}),e.jsx("td",{className:"border border-gray-300 px-3 py-2",children:(()=>{const c=je(s);return c?e.jsx("img",{src:c,alt:"画像",className:"w-8 h-8 object-cover rounded border",title:"故障画像",onError:i(h=>{const m=h.target;m.style.display="none"},"onError")}):e.jsx("span",{className:"text-gray-500",children:"-"})})()}),e.jsx("td",{className:"border border-gray-300 px-3 py-2",children:e.jsx("div",{className:"flex gap-2",children:e.jsxs(f,{variant:"outline",size:"sm",onClick:i(()=>{console.log("🔍 編集ボタンクリック - 元のアイテム:",s),console.log("🔍 item.machineType:",s.machineType),console.log("🔍 item.machineNumber:",s.machineNumber),console.log("🔍 item.jsonData:",s.jsonData);const c=Ce(s);console.log("🔍 正規化後のアイテム:",c),console.log("🔍 正規化後 machineType:",c.machineType),console.log("🔍 正規化後 machineNumber:",c.machineNumber),C(c),t(!0)},"onClick"),className:"flex items-center gap-1 text-xs",title:"編集画面を開く",children:[e.jsx(de,{className:"h-3 w-3"}),"編集"]})})})]},s.id)})})]})})})})]}),e.jsxs("div",{className:"bg-white rounded-lg shadow p-6 mb-6",children:[e.jsx("div",{className:"flex items-center justify-between mb-4",children:e.jsx("h2",{className:"text-xl font-bold",children:"エクスポート処理"})}),e.jsxs("div",{className:"flex flex-wrap gap-4 mb-4",children:[e.jsxs("div",{className:"flex gap-2",children:[e.jsxs(f,{onClick:i(()=>Me("json"),"onClick"),disabled:J||T.size===0,variant:"default",className:"flex items-center gap-2",children:[e.jsx(X,{className:"h-4 w-4"}),"選択履歴をJSONエクスポート (",T.size,")"]}),e.jsxs(f,{onClick:i(()=>Me("csv"),"onClick"),disabled:J||T.size===0,variant:"default",className:"flex items-center gap-2",children:[e.jsx(X,{className:"h-4 w-4"}),"選択履歴をCSVエクスポート (",T.size,")"]}),e.jsxs(f,{onClick:es,disabled:J||T.size===0,variant:"outline",className:"flex items-center gap-2",children:[e.jsx(Q,{className:"h-4 w-4"}),"選択の一覧を印刷 (",T.size,")"]})]}),e.jsxs("div",{className:"flex gap-2",children:[e.jsxs(f,{onClick:i(()=>Ae("json"),"onClick"),disabled:J,variant:"secondary",className:"flex items-center gap-2",children:[e.jsx(X,{className:"h-4 w-4"}),"全履歴をJSONエクスポート"]}),e.jsxs(f,{onClick:i(()=>Ae("csv"),"onClick"),disabled:J,variant:"secondary",className:"flex items-center gap-2",children:[e.jsx(X,{className:"h-4 w-4"}),"全履歴をCSVエクスポート"]})]})]}),J&&e.jsxs("div",{className:"flex items-center gap-2 text-blue-600",children:[e.jsx("div",{className:"animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"}),"エクスポート処理中..."]})]}),K>1&&e.jsx("div",{className:"flex justify-center mt-6",children:e.jsxs("div",{className:"flex gap-2",children:[e.jsx(f,{variant:"outline",onClick:i(()=>ue(M-1),"onClick"),disabled:M===1,children:"前へ"}),Array.from({length:Math.min(5,K)},(s,a)=>{const n=Math.max(1,Math.min(K-4,M-2))+a;return e.jsx(f,{variant:M===n?"default":"outline",onClick:i(()=>ue(n),"onClick"),children:n},n)}),e.jsx(f,{variant:"outline",onClick:i(()=>ue(M+1),"onClick"),disabled:M===K,children:"次へ"})]})}),j&&P&&e.jsx("div",{className:"fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50",children:e.jsx("div",{className:"bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-auto",children:e.jsxs("div",{className:"p-6",children:[e.jsxs("div",{className:"flex justify-between items-center mb-4",children:[e.jsx("h2",{className:"text-xl font-bold",children:"履歴プレビュー"}),e.jsxs("div",{className:"flex gap-2",children:[e.jsxs(f,{onClick:i(()=>Ee(P),"onClick"),className:"flex items-center gap-2",children:[e.jsx(Q,{className:"h-4 w-4"}),"印刷"]}),e.jsxs(f,{onClick:i(()=>{const s=Ce(P);C(s),y(!1),t(!0)},"onClick"),className:"flex items-center gap-2",children:[e.jsx(de,{className:"h-4 w-4"}),"編集に移動"]}),e.jsx(f,{variant:"ghost",onClick:i(()=>y(!1),"onClick"),children:"×"})]})]}),e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{className:"text-center border-b pb-4",children:[e.jsx("h1",{className:"text-2xl font-bold mb-2",children:"応急処置サポート履歴"}),e.jsxs("p",{className:"text-sm text-gray-500",children:["作成日時: ",re(P.createdAt)]})]}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6",children:[e.jsxs("div",{children:[e.jsx("h3",{className:"text-lg font-semibold mb-3",children:"基本情報"}),e.jsxs("div",{className:"space-y-2",children:[e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(de,{className:"h-4 w-4 text-gray-500"}),e.jsxs("span",{children:[e.jsx("strong",{children:"機種:"})," ",P.machineType]})]}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(Fe,{className:"h-4 w-4 text-gray-500"}),e.jsxs("span",{children:[e.jsx("strong",{children:"機械番号:"})," ",P.machineNumber]})]}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(Ue,{className:"h-4 w-4 text-gray-500"}),e.jsxs("span",{children:[e.jsx("strong",{children:"作成日時:"})," ",re(P.createdAt)]})]}),e.jsxs("div",{className:"flex items-center gap-2",children:[e.jsx(me,{className:"h-4 w-4 text-gray-500"}),e.jsxs("span",{children:[e.jsx("strong",{children:"画像:"})," ",P.imagePath?"あり":"なし"]})]})]})]}),P.imagePath&&e.jsxs("div",{children:[e.jsx("h3",{className:"text-lg font-semibold mb-3",children:"関連画像"}),e.jsx("img",{src:P.imagePath,alt:"履歴画像",className:"w-full h-48 object-cover rounded-md"})]})]}),e.jsxs("div",{children:[e.jsx("h3",{className:"text-lg font-semibold mb-3",children:"詳細情報"}),e.jsx("div",{className:"bg-gray-50 p-4 rounded-md",children:e.jsx("pre",{className:"text-sm overflow-auto max-h-64",children:JSON.stringify(P.jsonData,null,2)})})]})]})]})})}),W&&o&&e.jsx("div",{className:"fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50",children:e.jsx("div",{className:"bg-white rounded-lg max-w-5xl w-full max-h-[95vh] overflow-auto",children:e.jsxs("div",{className:"p-6",children:[(Y.machineTypes.length===0&&!ge&&$e(),console.log("編集ダイアログ表示時のeditingItem:",{machineType:o.machineType,machineNumber:o.machineNumber,fileName:o.fileName,title:o.jsonData?.title,question:o.jsonData?.question,jsonData:o.jsonData}),null),e.jsxs("div",{className:"flex justify-between items-center mb-4",children:[e.jsx("h2",{className:"text-xl font-bold",children:"機械故障情報編集"}),e.jsxs("div",{className:"flex gap-2",children:[e.jsxs(f,{onClick:i(()=>{console.log("編集データを保存します:",o),Re(o)},"onClick"),className:"flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white",children:[e.jsx(X,{className:"h-4 w-4"}),"保存"]}),e.jsxs(f,{onClick:i(()=>Ee(o),"onClick"),className:"flex items-center gap-2",children:[e.jsx(He,{className:"h-4 w-4"}),"印刷"]}),e.jsx(f,{variant:"outline",onClick:i(()=>{console.log("編集をキャンセルします"),t(!1),C(null)},"onClick"),children:"キャンセル"})]})]}),e.jsxs("div",{className:"space-y-6",children:[e.jsxs("div",{className:"bg-gray-50 p-4 rounded-lg",children:[e.jsxs("h3",{className:"text-lg font-semibold mb-3 flex items-center gap-2",children:[e.jsx(de,{className:"h-5 w-5"}),"基本情報"]}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-4",children:[e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium mb-2",children:"機種"}),ge?e.jsx("div",{className:"h-10 flex items-center px-3 border border-gray-300 rounded",children:"読み込み中..."}):e.jsxs(se,{value:o.machineType||"",onValueChange:i(s=>{console.log("機種を変更:",s),C({...o,machineType:s,jsonData:{...o.jsonData,machineType:s}})},"onValueChange"),children:[e.jsx(ae,{children:e.jsx(te,{placeholder:"機種を選択"})}),e.jsxs(ne,{children:[(console.log("🔍 機種Select - editingItem.machineType:",o.machineType),console.log("🔍 機種Select - machineData.machineTypes:",Y.machineTypes),null),Y.machineTypes.map(s=>e.jsx($,{value:s.machineTypeName,children:s.machineTypeName},s.id))]})]})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium mb-2",children:"機械番号"}),ge?e.jsx("div",{className:"h-10 flex items-center px-3 border border-gray-300 rounded",children:"読み込み中..."}):e.jsxs(se,{value:o.machineNumber||"",onValueChange:i(s=>{console.log("機械番号を変更:",s),C({...o,machineNumber:s,jsonData:{...o.jsonData,machineNumber:s}})},"onValueChange"),children:[e.jsx(ae,{children:e.jsx(te,{placeholder:"機械番号を選択"})}),e.jsx(ne,{children:Y.machines.filter(s=>!o.machineType||s.machineTypeName===o.machineType).map(s=>e.jsxs($,{value:s.machineNumber,children:[s.machineNumber," (",s.machineTypeName,")"]},s.id))})]})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium mb-2",children:"ファイル名"}),e.jsx(w,{value:o.fileName||"",onChange:i(s=>{console.log("ファイル名を変更:",s.target.value),C({...o,fileName:s.target.value})},"onChange"),placeholder:"ファイル名",disabled:!0})]})]})]}),e.jsxs("div",{className:"bg-blue-50 p-4 rounded-lg",children:[e.jsxs("h3",{className:"text-lg font-semibold mb-3 flex items-center gap-2",children:[e.jsx(Q,{className:"h-5 w-5"}),"事象・説明"]}),e.jsxs("div",{className:"space-y-4",children:[e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium mb-2",children:"事象タイトル"}),e.jsx(w,{value:o.jsonData?.title||o.jsonData?.question||"",onChange:i(s=>{console.log("事象タイトルを変更:",s.target.value),C({...o,jsonData:{...o.jsonData,title:s.target.value,question:s.target.value}})},"onChange"),placeholder:"事象タイトルを入力"}),(()=>{const s=o.jsonData?.title||o.jsonData?.question||"";return console.log("🔍 事象タイトル - 表示値:",s),console.log("🔍 事象タイトル - jsonData.title:",o.jsonData?.title),console.log("🔍 事象タイトル - jsonData.question:",o.jsonData?.question),null})()]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium mb-2",children:"事象説明"}),e.jsx("textarea",{value:o.jsonData?.problemDescription||o.jsonData?.answer||"",onChange:i(s=>{console.log("事象説明を変更:",s.target.value),C({...o,jsonData:{...o.jsonData,problemDescription:s.target.value,answer:s.target.value}})},"onChange"),className:"w-full h-24 p-3 border border-gray-300 rounded-md",placeholder:"事象の詳細説明を入力"})]})]})]}),(()=>{const s=je(o);return s?e.jsxs("div",{className:"bg-purple-50 p-4 rounded-lg",children:[e.jsxs("h3",{className:"text-lg font-semibold mb-3 flex items-center gap-2",children:[e.jsx(me,{className:"h-5 w-5"}),"故障個所の画像"]}),e.jsxs("div",{className:"text-center",children:[e.jsx("img",{src:s,alt:"故障画像",className:"max-w-full max-h-64 mx-auto border border-gray-300 rounded-md shadow-sm"}),e.jsxs("p",{className:"text-sm text-gray-600 mt-2",children:["故障箇所の画像 ",s.startsWith("data:image/")?"(Base64)":"(URL)"]})]})]}):null})(),e.jsxs("div",{className:"bg-yellow-50 p-4 rounded-lg",children:[e.jsxs("h3",{className:"text-lg font-semibold mb-3 flex items-center gap-2",children:[e.jsx(Fe,{className:"h-5 w-5"}),"修繕計画"]}),e.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-4",children:[e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium mb-2",children:"修繕予定月日"}),e.jsx(w,{type:"date",value:o.jsonData?.repairSchedule||"",onChange:i(s=>{C({...o,jsonData:{...o.jsonData,repairSchedule:s.target.value}})},"onChange"),placeholder:"修繕予定月日"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium mb-2",children:"場所"}),e.jsx(w,{value:o.jsonData?.location||"",onChange:i(s=>{C({...o,jsonData:{...o.jsonData,location:s.target.value}})},"onChange"),placeholder:"設置場所"})]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium mb-2",children:"ステータス"}),e.jsxs(se,{value:o.jsonData?.status||"",onValueChange:i(s=>{C({...o,jsonData:{...o.jsonData,status:s}})},"onValueChange"),children:[e.jsx(ae,{children:e.jsx(te,{placeholder:"ステータスを選択"})}),e.jsxs(ne,{children:[e.jsx($,{value:"報告済み",children:"報告済み"}),e.jsx($,{value:"対応中",children:"対応中"}),e.jsx($,{value:"完了",children:"完了"}),e.jsx($,{value:"保留",children:"保留"})]})]})]})]})]}),e.jsxs("div",{className:"bg-gray-50 p-4 rounded-lg",children:[e.jsxs("h3",{className:"text-lg font-semibold mb-3 flex items-center gap-2",children:[e.jsx(Q,{className:"h-5 w-5"}),"記事欄"]}),e.jsxs("div",{children:[e.jsx("label",{className:"block text-sm font-medium mb-2",children:"備考・記事 (200文字以内)"}),e.jsx("textarea",{value:o.jsonData?.remarks||"",onChange:i(s=>{s.target.value.length<=200&&C({...o,jsonData:{...o.jsonData,remarks:s.target.value}})},"onChange"),className:"w-full h-24 p-3 border border-gray-300 rounded-md",placeholder:"修繕に関する備考や追加情報を記載してください（200文字以内）",maxLength:200}),e.jsxs("p",{className:"text-xs text-gray-500 mt-1",children:[o.jsonData?.remarks?.length||0,"/200文字"]})]})]}),e.jsxs("div",{className:"flex justify-end gap-2 pt-4 border-t",children:[e.jsx(f,{variant:"outline",onClick:i(()=>{console.log("編集をキャンセルします"),t(!1),C(null)},"onClick"),children:"キャンセル"}),e.jsx(f,{onClick:i(()=>{console.log("編集データを保存します:",o),Re(o)},"onClick"),className:"bg-green-600 hover:bg-green-700 text-white",children:"保存して適用"})]})]})]})})}),Je&&we&&e.jsx(xs,{data:we,fileName:De,onClose:Ge,onSave:Ze,onPrint:i(s=>{console.log("チャットエクスポートレポートを印刷:",s),window.print()},"onPrint")})]})},"HistoryPage");var Rs=gs;export{Rs as default};
//# sourceMappingURL=history-GFy7iDpW.js.map
