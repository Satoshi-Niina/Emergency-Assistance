import{d as c}from"./index-BSVp3Gue.js";const r=c("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);const t=c("Circle",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]);export{t as C,r as a};
//# sourceMappingURL=circle-B2eFA0rH.js.map
