// グローバル型定義ファイル
interface Window {
  queryClient: any;
}