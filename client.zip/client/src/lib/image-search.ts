export const reloadImageSearchData = async () => {
  // stub: in real implementation this reloads local image search index
  return Promise.resolve();
};
