# Emergency Assistance Server

## Overview
Emergency assistance system backend server

## Build
```bash
npm ci
npm run build
```

## Start Production
```bash
npm run start:production
```

## Test Update
This file was updated to test GitHub Actions workflow execution.
