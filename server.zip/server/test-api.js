// API テストツール
import http from 'http';

function testAPI(endpoint, expectedStatus = 200) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'localhost',
      port: 8081,
      path: endpoint,
      method: 'GET',
      headers: {
        'Content-Type': 'application/json'
      }
    };

    const req = http.request(options, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        try {
          const jsonData = JSON.parse(data);
          console.log(`✅ ${endpoint}: Status ${res.statusCode}`);
          console.log(`   Success: ${jsonData.success}`);
          console.log(`   Data count: ${jsonData.data ? jsonData.data.length : 'N/A'}`);
          if (jsonData.message) console.log(`   Message: ${jsonData.message}`);
          resolve({ status: res.statusCode, data: jsonData });
        } catch (e) {
          console.log(`❌ ${endpoint}: JSON解析エラー`);
          console.log(`   Raw response: ${data.substring(0, 200)}...`);
          resolve({ status: res.statusCode, data: null, error: e.message });
        }
      });
    });

    req.on('error', (err) => {
      console.log(`❌ ${endpoint}: 接続エラー - ${err.message}`);
      resolve({ status: 0, error: err.message });
    });

    req.setTimeout(5000, () => {
      req.destroy();
      console.log(`❌ ${endpoint}: タイムアウト`);
      resolve({ status: 0, error: 'timeout' });
    });

    req.end();
  });
}

async function runTests() {
  console.log('🔍 APIエンドポイントテスト開始...\n');

  const endpoints = [
    '/api/health',
    '/api/users',
    '/api/machines/machine-types',
    '/api/machines/machines',
    '/api/machines/machines?type_id=1',
    '/api/storage/list?prefix=knowledge-base',
  ];

  for (const endpoint of endpoints) {
    await testAPI(endpoint);
    await new Promise(resolve => setTimeout(resolve, 500)); // 500ms待機
  }

  console.log('\n🎉 APIテスト完了');
}

// ES module: 直接実行
runTests();