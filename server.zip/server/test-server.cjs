const express = require('express');
const fs = require('fs').promises;
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3002;

// CORSを有効にする
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  next();
});

app.use(express.json());

// ローカルファイル一覧を取得するAPI
app.get('/api/history/local-files', async (req, res) => {
  try {
    const exportDir = process.env.LOCAL_EXPORT_DIR || path.join(__dirname, '..', 'knowledge-base', 'exports');
    console.log('📋 履歴詳細取得リクエスト: local-files');
    console.log('📂 Directory path:', exportDir);
    
    const files = await fs.readdir(exportDir);
    const jsonFiles = files.filter(file => file.endsWith('.json'));
    
    console.log('📁 Found files:', jsonFiles);
    
    const filesData = await Promise.all(
      jsonFiles.map(async (filename) => {
        try {
          const filePath = path.join(exportDir, filename);
          const content = await fs.readFile(filePath, 'utf8');
          const data = JSON.parse(content);
          
          return {
            filename,
            id: data.id || filename.replace('.json', ''),
            machine_number: data.machine_number || '',
            problem_category: data.problem_category || '',
            problem_description: data.problem_description || '',
            created_at: data.created_at || '',
            status: data.status || 'completed',
            source: 'export'
          };
        } catch (error) {
          console.error(`Error reading file ${filename}:`, error);
          return null;
        }
      })
    );
    
    const validFiles = filesData.filter(file => file !== null);
    console.log('✅ Valid files:', validFiles.length);
    
    res.json(validFiles);
  } catch (error) {
    console.error('Error reading local files:', error);
    res.status(500).json({ error: 'Failed to read local files' });
  }
});

// 特定のファイルを取得するAPI
app.get('/api/history/local-files/:filename', async (req, res) => {
  try {
    const { filename } = req.params;
    const exportDir = process.env.LOCAL_EXPORT_DIR || path.join(__dirname, '..', 'knowledge-base', 'exports');
    const filePath = path.join(exportDir, filename);
    
    console.log('📋 履歴詳細取得リクエスト:', filename);
    console.log('📂 File path:', filePath);
    
    const content = await fs.readFile(filePath, 'utf8');
    const data = JSON.parse(content);
    
    res.json(data);
  } catch (error) {
    console.error('Error reading file:', error);
    res.status(404).json({ error: 'File not found' });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Test server running on port ${PORT}`);
  console.log(`🔗 API: http://localhost:${PORT}/api`);
  console.log(`📂 Export directory: ${process.env.LOCAL_EXPORT_DIR || path.join(__dirname, '..', 'knowledge-base', 'exports')}`);
});