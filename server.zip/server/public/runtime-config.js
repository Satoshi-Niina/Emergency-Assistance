window.runtimeConfig = {
  "API_BASE_URL": "/api",
  "CORS_ALLOW_ORIGINS": "*",
  "ENVIRONMENT": "development"
};