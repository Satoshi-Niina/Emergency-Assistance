#!/usr/bin/env node

// 統合サーバー - フロントエンドとAPIを統合
// Docker環境で動作する統合サーバー

import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { Pool } from 'pg';
import bcrypt from 'bcryptjs';

// ESM __dirname equivalent
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// 環境変数の読み込み
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
  dotenv.config({ path: envPath });
  console.log('📄 Loaded .env file from:', envPath);
  console.log('📄 DATABASE_URL exists:', !!process.env.DATABASE_URL);
} else {
  console.log('📄 .env file not found at:', envPath);
  console.log('📄 Using system environment variables');
}

const app = express();
const PORT = process.env.PORT || 8080;

// 開発環境の判定
const isDevelopment = process.env.NODE_ENV === 'development';

// データベース接続プール
let dbPool = null;

// データベース初期化
function initializeDatabase() {
  // 開発環境では常にDB接続を試行（BYPASS_DB_FOR_LOGINは認証のみに使用）
  if (!process.env.DATABASE_URL) {
    console.warn('⚠️ DATABASE_URL is not set - running without database');
    return;
  }

  try {
    console.log('🔗 Initializing database connection...');
    
    // ローカル開発環境ではSSLを無効化
    const isLocalhost = process.env.DATABASE_URL.includes('localhost') || 
                       process.env.DATABASE_URL.includes('127.0.0.1');
    
    const sslConfig = isLocalhost 
      ? false  // ローカルではSSL無効
      : process.env.PG_SSL === 'require' 
      ? { rejectUnauthorized: false }
      : process.env.PG_SSL === 'disable' 
      ? false 
      : { rejectUnauthorized: false };
    
    dbPool = new Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: sslConfig,
      max: 5,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 60000,
    });

    console.log('✅ Database pool initialized');
  } catch (error) {
    console.error('❌ Database initialization failed:', error);
  }
}

// データベース初期化
initializeDatabase();

// CORS設定
const corsOrigins = process.env.CORS_ALLOW_ORIGINS?.split(',') || ['*'];
app.use(cors({
  origin: corsOrigins.includes('*') ? true : corsOrigins,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Cache-Control', 'Pragma', 'Expires']
}));

// ミドルウェア
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// 静的ファイル配信（フロントエンド）
app.use(express.static(path.join(__dirname, 'public'), {
  maxAge: '1d',
  etag: true,
  lastModified: true
}));

// API router - server/src/api の Azure Functions を統合
const apiRouter = express.Router();

// Azure Functions のヘルスチェックを統合
apiRouter.get('/health', async (req, res) => {
  try {
    // server/src/api/health/index.js の処理を再現
    const healthCheck = require('./src/api/health/index.js');
    const context = {
      log: console.log,
      res: null
    };
    
    await healthCheck(context, { method: req.method });
    
    if (context.res) {
      res.status(context.res.status || 200);
      if (context.res.headers) {
        Object.keys(context.res.headers).forEach(key => {
          res.setHeader(key, context.res.headers[key]);
        });
      }
      res.send(context.res.body || '');
    } else {
      res.json({ 
        status: 'ok', 
        timestamp: new Date().toISOString()
      });
    }
  } catch (error) {
    console.error('Health check error:', error);
    res.status(500).json({ 
      status: 'error', 
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// 認証API - Azure Functions の auth/login を統合
apiRouter.post('/auth/login', async (req, res) => {
  try {
    console.log('Login attempt received:', req.body);
    const { username, password } = req.body;
    
    if (!username || !password) {
      console.log('Missing username or password');
      return res.status(400).json({ 
        success: false, 
        error: 'bad_request',
        message: 'ユーザー名とパスワードが必要です'
      });
    }

    console.log(`Attempting login for user: ${username}`);
    console.log(`Database pool available: ${!!dbPool}`);

    // データベース認証を試行
    if (dbPool) {
      try {
        console.log('Attempting database authentication...');
        const result = await dbPool.query(
          'SELECT id, username, password, role, display_name, department FROM users WHERE username = $1 LIMIT 1',
          [username]
        );
        
        if (result.rows.length === 0) {
          console.log('User not found in database');
          return res.status(401).json({ 
            success: false, 
            error: 'invalid_credentials',
            message: 'ユーザー名またはパスワードが正しくありません'
          });
        }
        
        const user = result.rows[0];
        console.log('User found in database:', user.username);
        const isValidPassword = await bcrypt.compare(password, user.password);
        
        if (!isValidPassword) {
          console.log('Password validation failed');
          return res.status(401).json({ 
            success: false, 
            error: 'invalid_credentials',
            message: 'ユーザー名またはパスワードが正しくありません'
          });
        }
        
        console.log('Database authentication successful');
        res.json({ 
          success: true, 
          user: {
            id: user.id,
            username: user.username,
            role: user.role,
            displayName: user.display_name,
            display_name: user.display_name,
            department: user.department
          },
          message: 'ログインに成功しました'
        });
      } catch (dbError) {
        console.error('Database error, falling back to simple auth:', dbError.message);
        // データベースエラーの場合、簡易認証にフォールバック
        return handleSimpleAuth(username, password, res);
      }
    } else {
      // データベースなしの簡易認証
      return handleSimpleAuth(username, password, res);
    }

    // 簡易認証の処理関数
    function handleSimpleAuth(username, password, res) {
      console.log('Using simple authentication without database');
      console.log(`Provided credentials: username="${username}", password="${password}"`);
      
      // 複数のテストユーザーをサポート
      const testUsers = {
        'admin': { password: 'admin', role: 'admin', displayName: 'Administrator', department: 'IT' },
        'niina': { password: 'G&896845', role: 'admin', displayName: 'Satoshi Niina', department: 'IT' }
      };
      
      const user = testUsers[username];
      if (user && password === user.password) {
        console.log('Simple authentication successful');
        return res.json({ 
          success: true, 
          user: { 
            id: 1, 
            username: username, 
            role: user.role,
            displayName: user.displayName,
            display_name: user.displayName,
            department: user.department
          },
          message: 'ログインに成功しました'
        });
      } else {
        console.log('Simple authentication failed - invalid credentials');
        return res.status(401).json({ 
          success: false, 
          error: 'invalid_credentials',
          message: 'ユーザー名またはパスワードが正しくありません'
        });
      }
    }
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ 
      success: false,
      error: 'internal_server_error',
      message: 'サーバーエラーが発生しました'
    });
  }
});

apiRouter.post('/auth/logout', (req, res) => {
  res.json({ 
    success: true, 
    message: 'ログアウトしました'
  });
});

// 機種一覧取得API
apiRouter.get('/machines/machine-types', async (req, res) => {
  try {
    console.log('🔍 機種一覧取得リクエスト');
    
    // データベース接続がある場合
    if (dbPool) {
      try {
        const result = await dbPool.query(`
          SELECT id, machine_type_name as machine_type_name 
          FROM machine_types 
          ORDER BY machine_type_name
        `);
        
        return res.json({
          success: true,
          data: result.rows,
          total: result.rows.length,
          timestamp: new Date().toISOString()
        });
      } catch (dbError) {
        console.error('Database error:', dbError.message);
      }
    }
    
    // フォールバック: ダミーデータ
    const dummyData = [
      { id: '1', machine_type_name: 'MT-100' },
      { id: '2', machine_type_name: 'MR-400' },
      { id: '3', machine_type_name: 'TC-250' },
      { id: '4', machine_type_name: 'SS-750' }
    ];
    
    res.json({
      success: true,
      data: dummyData,
      total: dummyData.length,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ 機種一覧取得エラー:', error);
    res.status(500).json({
      success: false,
      error: '機種一覧の取得に失敗しました',
      details: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// 機械番号一覧取得API
apiRouter.get('/machines', async (req, res) => {
  try {
    const { type_id } = req.query;
    console.log('🔍 機械番号一覧取得リクエスト:', { type_id });
    
    if (!type_id) {
      // type_idが指定されていない場合は空のデータを返す
      return res.json({
        success: true,
        data: [],
        message: '機種IDが指定されていません',
        timestamp: new Date().toISOString()
      });
    }
    
    // データベース接続がある場合
    if (dbPool) {
      try {
        const result = await dbPool.query(`
          SELECT id, machine_number as machine_number 
          FROM machines 
          WHERE machine_type_id = $1 
          ORDER BY machine_number
        `, [type_id]);
        
        return res.json({
          success: true,
          data: result.rows,
          total: result.rows.length,
          timestamp: new Date().toISOString()
        });
      } catch (dbError) {
        console.error('Database error:', dbError.message);
      }
    }
    
    // フォールバック: ダミーデータ
    const dummyData = [
      { id: '1', machine_number: 'M001' },
      { id: '2', machine_number: 'M002' },
      { id: '3', machine_number: 'M003' }
    ];
    
    res.json({
      success: true,
      data: dummyData,
      total: dummyData.length,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ 機械番号一覧取得エラー:', error);
    res.status(500).json({
      success: false,
      error: '機械番号一覧の取得に失敗しました',
      details: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// ユーザー一覧取得API
apiRouter.get('/users', async (req, res) => {
  try {
    console.log('🔍 ユーザー一覧取得リクエスト');
    
    // データベース接続がある場合
    if (dbPool) {
      try {
        const result = await dbPool.query(`
          SELECT id, username, display_name, role, department, description, created_at
          FROM users
          ORDER BY created_at DESC
        `);
        
        return res.json({
          success: true,
          data: result.rows,
          total: result.rows.length,
          timestamp: new Date().toISOString()
        });
      } catch (dbError) {
        console.error('Database error:', dbError.message);
      }
    }
    
    // データベース接続がない場合は空のデータを返す
    res.json({
      success: true,
      data: [],
      total: 0,
      message: 'データベース接続がありません',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ ユーザー一覧取得エラー:', error);
    res.status(500).json({
      success: false,
      error: 'ユーザー一覧の取得に失敗しました',
      details: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// 履歴一覧取得API
apiRouter.get('/history', async (req, res) => {
  try {
    console.log('📋 履歴一覧取得リクエスト');
    
    // knowledge-base/exports フォルダからファイルを読み込み
    const exportsDir = path.join(process.cwd(), 'knowledge-base', 'exports');
    
    if (!fs.existsSync(exportsDir)) {
      return res.json({
        success: true,
        data: [],
        total: 0,
        message: 'エクスポートディレクトリが存在しません',
        timestamp: new Date().toISOString()
      });
    }
    
    const files = fs.readdirSync(exportsDir);
    const jsonFiles = files.filter(file => file.endsWith('.json'));
    
    const historyItems = jsonFiles.map(file => {
      try {
        const filePath = path.join(exportsDir, file);
        const fileContent = fs.readFileSync(filePath, 'utf-8');
        const jsonData = JSON.parse(fileContent);
        
        return {
          id: jsonData.chatId || file.replace('.json', ''),
          fileName: file,
          title: jsonData.title || 'タイトルなし',
          machineType: jsonData.machineType || 'Unknown',
          machineNumber: jsonData.machineNumber || 'Unknown',
          createdAt: jsonData.exportTimestamp || new Date().toISOString(),
          lastModified: jsonData.exportTimestamp || new Date().toISOString()
        };
      } catch (error) {
        console.error(`ファイル読み込みエラー: ${file}`, error);
        return null;
      }
    }).filter(item => item !== null);
    
    res.json({
      success: true,
      data: historyItems,
      total: historyItems.length,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ 履歴一覧取得エラー:', error);
    res.status(500).json({
      success: false,
      error: '履歴一覧の取得に失敗しました',
      details: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// 応急処置フロー一覧取得API
apiRouter.get('/emergency-flow/list', async (req, res) => {
  try {
    console.log('🔍 応急処置フロー一覧取得リクエスト');
    
    // knowledge-base/troubleshooting フォルダからファイルを読み込み
    const troubleshootingDir = path.join(process.cwd(), 'knowledge-base', 'troubleshooting');
    
    // サーバーディレクトリから起動されている場合の代替パス
    const alternativeDir = path.join(process.cwd(), '..', 'knowledge-base', 'troubleshooting');
    
    // ディレクトリの存在確認と適切なパスの選択
    let targetDir = troubleshootingDir;
    if (!fs.existsSync(troubleshootingDir)) {
      console.log('❌ メインディレクトリが存在しません、代替パスを試行中...');
      if (fs.existsSync(alternativeDir)) {
        console.log(`✅ 代替パスが見つかりました: ${alternativeDir}`);
        targetDir = alternativeDir;
      } else {
        console.error('❌ どのパスでもディレクトリが見つかりませんでした');
        return res.json({
          success: false,
          error: 'トラブルシューティングディレクトリが見つかりません',
          timestamp: new Date().toISOString()
        });
      }
    }
    
    const files = fs.readdirSync(targetDir);
    const jsonFiles = files.filter(file => file.endsWith('.json'));
    
    const flows = jsonFiles.map(file => {
      try {
        const filePath = path.join(targetDir, file);
        const fileContent = fs.readFileSync(filePath, 'utf-8');
        const jsonData = JSON.parse(fileContent);
        
        return {
          id: jsonData.id || file.replace('.json', ''),
          title: jsonData.title || 'タイトルなし',
          description: jsonData.description || '',
          fileName: file,
          filePath: `knowledge-base/troubleshooting/${file}`,
          createdAt: jsonData.createdAt || new Date().toISOString(),
          updatedAt: jsonData.updatedAt || new Date().toISOString(),
          triggerKeywords: jsonData.triggerKeywords || [],
          category: jsonData.category || '',
          steps: jsonData.steps || [],
          dataSource: 'file'
        };
      } catch (error) {
        console.error(`ファイル読み込みエラー: ${file}`, error);
        return null;
      }
    }).filter(item => item !== null);
    
    res.json({
      success: true,
      data: flows,
      total: flows.length,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ 応急処置フロー一覧取得エラー:', error);
    res.status(500).json({
      success: false,
      error: '応急処置フロー一覧の取得に失敗しました',
      details: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// チャット送信API（プレースホルダー）
apiRouter.post('/chats/:id/send', (req, res) => {
  const { id } = req.params;
  const { chatData } = req.body;
  
  console.log('📤 チャット送信リクエスト:', { id, messageCount: chatData?.messages?.length || 0 });
  
  // knowledge-base/exports フォルダを作成
  const exportsDir = path.join(process.cwd(), 'knowledge-base', 'exports');
  if (!fs.existsSync(exportsDir)) {
    fs.mkdirSync(exportsDir, { recursive: true });
    console.log('exports フォルダを作成しました:', exportsDir);
  }
  
  // チャットデータを保存
  const fileName = `chat_${id}_${Date.now()}.json`;
  const filePath = path.join(exportsDir, fileName);
  
  const exportData = {
    chatId: id,
    title: chatData.title || 'チャット履歴',
    machineType: chatData.machineInfo?.machineTypeName || '',
    machineNumber: chatData.machineInfo?.machineNumber || '',
    exportTimestamp: new Date().toISOString(),
    chatData: chatData,
    exportType: 'manual'
  };
  
  fs.writeFileSync(filePath, JSON.stringify(exportData, null, 2));
  
  res.json({
    success: true,
    message: 'チャット内容をサーバーに送信しました',
    fileName: fileName,
    timestamp: new Date().toISOString()
  });
});

// 履歴の機種・機械番号データ取得API
apiRouter.get('/history/machine-data', async (req, res) => {
  try {
    console.log('📋 機種・機械番号データ取得リクエスト（履歴用）');
    
    // データベース接続がある場合
    if (dbPool) {
      try {
        const machineTypesResult = await dbPool.query(`
          SELECT id, machine_type_name as "machineTypeName"
          FROM machine_types
          ORDER BY machine_type_name
        `);
        
        const machinesResult = await dbPool.query(`
          SELECT m.id, m.machine_number as "machineNumber", m.machine_type_id as "machineTypeId", 
                 mt.machine_type_name as "machineTypeName"
          FROM machines m
          LEFT JOIN machine_types mt ON m.machine_type_id = mt.id
          ORDER BY m.machine_number
        `);
        
        return res.json({
          success: true,
          machineTypes: machineTypesResult.rows,
          machines: machinesResult.rows,
          timestamp: new Date().toISOString()
        });
      } catch (dbError) {
        console.error('Database error:', dbError.message);
      }
    }
    
    // データベース接続がない場合は空のデータを返す
    res.json({
      success: true,
      machineTypes: [],
      machines: [],
      message: 'データベース接続がありません',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ 機種・機械番号データ取得エラー:', error);
    res.status(500).json({
      success: false,
      error: '機種・機械番号データの取得に失敗しました',
      details: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// 履歴詳細取得API（JSON+画像）
apiRouter.get('/history/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`📋 履歴詳細取得リクエスト: ${id}`);
    
    // knowledge-base/exports から該当ファイルを検索
    const exportsDir = path.join(process.cwd(), 'knowledge-base', 'exports');
    const alternativeDir = path.join(process.cwd(), '..', 'knowledge-base', 'exports');
    
    let targetDir = exportsDir;
    if (!fs.existsSync(exportsDir)) {
      if (fs.existsSync(alternativeDir)) {
        targetDir = alternativeDir;
      } else {
        return res.status(404).json({
          success: false,
          error: 'エクスポートディレクトリが見つかりません',
          timestamp: new Date().toISOString()
        });
      }
    }
    
    const files = fs.readdirSync(targetDir);
    const jsonFiles = files.filter(file => file.endsWith('.json'));
    
    let foundFile = null;
    let foundData = null;
    
    for (const file of jsonFiles) {
      try {
        const filePath = path.join(targetDir, file);
        const fileContent = fs.readFileSync(filePath, 'utf-8');
        const jsonData = JSON.parse(fileContent);
        
        if (jsonData.chatId === id || file.replace('.json', '') === id) {
          foundFile = file;
          foundData = jsonData;
          break;
        }
      } catch (error) {
        console.error(`ファイル読み込みエラー: ${file}`, error);
      }
    }
    
    if (!foundData) {
      return res.status(404).json({
        success: false,
        error: '履歴が見つかりません',
        details: `ID: ${id} の履歴が見つかりませんでした`,
        timestamp: new Date().toISOString()
      });
    }
    
    res.json({
      success: true,
      data: foundData,
      fileName: foundFile,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ 履歴詳細取得エラー:', error);
    res.status(500).json({
      success: false,
      error: '履歴詳細の取得に失敗しました',
      details: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// 応急処置フロー詳細取得API（JSON+画像）
apiRouter.get('/emergency-flow/detail/:id', async (req, res) => {
  try {
    const { id } = req.params;
    console.log(`🔍 応急処置フロー詳細取得リクエスト: ${id}`);
    
    const troubleshootingDir = path.join(process.cwd(), 'knowledge-base', 'troubleshooting');
    const alternativeDir = path.join(process.cwd(), '..', 'knowledge-base', 'troubleshooting');
    
    let targetDir = troubleshootingDir;
    if (!fs.existsSync(troubleshootingDir)) {
      if (fs.existsSync(alternativeDir)) {
        targetDir = alternativeDir;
      } else {
        return res.status(404).json({
          success: false,
          error: 'トラブルシューティングディレクトリが見つかりません',
          timestamp: new Date().toISOString()
        });
      }
    }
    
    const files = fs.readdirSync(targetDir);
    const jsonFiles = files.filter(file => file.endsWith('.json'));
    
    let flowData = null;
    let fileName = null;
    
    for (const file of jsonFiles) {
      try {
        const filePath = path.join(targetDir, file);
        const fileContent = fs.readFileSync(filePath, 'utf-8');
        const data = JSON.parse(fileContent);
        
        if (data.id === id || file.replace('.json', '') === id) {
          flowData = data;
          fileName = file;
          break;
        }
      } catch (error) {
        console.error(`ファイル読み込みエラー: ${file}`, error);
      }
    }
    
    if (!flowData) {
      return res.status(404).json({
        success: false,
        error: 'フローが見つかりません',
        details: `ID: ${id} のフローデータが見つかりませんでした`,
        timestamp: new Date().toISOString()
      });
    }
    
    // 画像URLを完全なURLに変換
    if (flowData.steps) {
      flowData.steps.forEach((step, index) => {
        if (step.images && Array.isArray(step.images)) {
          step.images.forEach((img, imgIndex) => {
            if (img.url && !img.url.startsWith('http')) {
              img.url = `${req.protocol}://${req.get('host')}/api/images/${img.url}`;
            }
          });
        }
      });
    }
    
    res.json({
      success: true,
      data: flowData,
      fileName: fileName,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ 応急処置フロー詳細取得エラー:', error);
    res.status(500).json({
      success: false,
      error: '応急処置フロー詳細の取得に失敗しました',
      details: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// 画像ファイル配信API
apiRouter.get('/images/*', (req, res) => {
  try {
    const imagePath = req.params[0];
    const troubleshootingDir = path.join(process.cwd(), 'knowledge-base', 'troubleshooting');
    const alternativeDir = path.join(process.cwd(), '..', 'knowledge-base', 'troubleshooting');
    
    let targetDir = troubleshootingDir;
    if (!fs.existsSync(troubleshootingDir)) {
      if (fs.existsSync(alternativeDir)) {
        targetDir = alternativeDir;
      } else {
        return res.status(404).json({ error: 'ディレクトリが見つかりません' });
      }
    }
    
    const fullPath = path.join(targetDir, imagePath);
    
    if (fs.existsSync(fullPath)) {
      res.sendFile(fullPath);
    } else {
      res.status(404).json({ error: '画像ファイルが見つかりません' });
    }
  } catch (error) {
    console.error('❌ 画像配信エラー:', error);
    res.status(500).json({ error: '画像の配信に失敗しました' });
  }
});

// その他のAPIエンドポイント（プレースホルダー）
apiRouter.post('/chatgpt', (req, res) => {
  const { message } = req.body;
  res.json({
    response: `Echo: ${message}`,
    timestamp: new Date().toISOString()
  });
});

// ナレッジベースAPI
apiRouter.get('/knowledge-base', async (req, res) => {
  try {
    console.log('📚 ナレッジベース取得リクエスト');
    
    // knowledge-base ディレクトリからファイル一覧を取得
    const knowledgeBaseDir = path.join(process.cwd(), 'knowledge-base');
    const alternativeDir = path.join(process.cwd(), '..', 'knowledge-base');
    
    let targetDir = knowledgeBaseDir;
    if (!fs.existsSync(knowledgeBaseDir)) {
      if (fs.existsSync(alternativeDir)) {
        targetDir = alternativeDir;
      } else {
        return res.json({
          success: true,
          data: [],
          message: 'ナレッジベースディレクトリが見つかりません',
          timestamp: new Date().toISOString()
        });
      }
    }
    
    const files = fs.readdirSync(targetDir);
    const jsonFiles = files.filter(file => file.endsWith('.json'));
    
    const knowledgeItems = jsonFiles.map(file => {
      try {
        const filePath = path.join(targetDir, file);
        const fileContent = fs.readFileSync(filePath, 'utf-8');
        const jsonData = JSON.parse(fileContent);
        
        return {
          id: file.replace('.json', ''),
          fileName: file,
          title: jsonData.title || 'タイトルなし',
          category: jsonData.category || 'unknown',
          createdAt: jsonData.createdAt || new Date().toISOString(),
          lastModified: jsonData.lastModified || new Date().toISOString()
        };
      } catch (error) {
        console.error(`ファイル読み込みエラー: ${file}`, error);
        return null;
      }
    }).filter(item => item !== null);
    
    res.json({
      success: true,
      data: knowledgeItems,
      total: knowledgeItems.length,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ ナレッジベース取得エラー:', error);
    res.status(500).json({
      success: false,
      error: 'ナレッジベースの取得に失敗しました',
      details: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// 設定RAG API
apiRouter.get('/settings/rag', async (req, res) => {
  try {
    console.log('⚙️ RAG設定取得リクエスト');
    
    res.json({
      success: true,
      data: {
        enabled: true,
        model: 'gpt-3.5-turbo',
        temperature: 0.7,
        maxTokens: 1000,
        chunkSize: 1000,
        overlap: 200
      },
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ RAG設定取得エラー:', error);
    res.status(500).json({
      success: false,
      error: 'RAG設定の取得に失敗しました',
      details: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// 管理者ダッシュボードAPI
apiRouter.get('/admin/dashboard', async (req, res) => {
  try {
    console.log('📊 管理者ダッシュボード取得リクエスト');
    
    res.json({
      success: true,
      data: {
        totalUsers: 0,
        totalMachines: 0,
        totalHistory: 0,
        totalFlows: 0,
        systemStatus: 'running',
        lastUpdate: new Date().toISOString()
      },
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('❌ 管理者ダッシュボード取得エラー:', error);
    res.status(500).json({
      success: false,
      error: '管理者ダッシュボードの取得に失敗しました',
      details: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

apiRouter.get('/knowledge-base/*', (req, res) => {
  res.json({ 
    data: [],
    message: 'Knowledge base API placeholder'
  });
});

// 故障履歴ルートを動的にインポート（ES modules対応）
try {
  const faultHistoryModule = await import('./routes/fault-history.js');
  apiRouter.use('/fault-history', faultHistoryModule.default);
  console.log('✅ 故障履歴ルートを追加しました');
} catch (error) {
  console.warn('⚠️ 故障履歴ルートの読み込みに失敗:', error.message);
}

// APIルーターをマウント
app.use('/api', apiRouter);

// SPAルーティング - すべての非APIリクエストをindex.htmlにリダイレクト
app.get('*', (req, res) => {
  // APIルートは除外
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'API endpoint not found' });
  }
  
  // 静的ファイルが存在する場合はそれを返す
  const filePath = path.join(__dirname, 'public', req.path);
  if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
    return res.sendFile(filePath);
  }
  
  // それ以外はSPAのindex.htmlを返す
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ローカルファイル一覧取得API
app.get('/api/history/local-files', async (req, res) => {
  try {
    console.log('[api/history/local-files] ローカルファイル一覧取得リクエスト');
    
    const fs = require('fs').promises;
    const path = require('path');
    
    // 履歴ファイルを保存するディレクトリを指定（環境変数対応）
    const historyDir = process.env.LOCAL_HISTORY_DIR || path.join(__dirname, 'app-logs', 'history');
    const exportDir = process.env.LOCAL_EXPORT_DIR || path.join(__dirname, 'app-logs', 'exports');
    
    let files = [];
    
    try {
      // historyディレクトリから.jsonファイルを取得
      try {
        const historyFiles = await fs.readdir(historyDir);
        const historyJsonFiles = historyFiles.filter(file => file.endsWith('.json'));
        files = [...files, ...historyJsonFiles.map(file => ({ file, dir: 'history' }))];
      } catch (error) {
        console.log('[api/history/local-files] historyディレクトリが存在しません');
      }
      
      // exportsディレクトリから.jsonファイルを取得
      try {
        const exportFiles = await fs.readdir(exportDir);
        const exportJsonFiles = exportFiles.filter(file => file.endsWith('.json'));
        files = [...files, ...exportJsonFiles.map(file => ({ file, dir: 'exports' }))];
      } catch (error) {
        console.log('[api/history/local-files] exportsディレクトリが存在しません');
      }
      
      console.log('[api/history/local-files] ファイル一覧取得成功:', files.length + '件');
      
      res.json({
        success: true,
        files: files.map(f => f.file),
        directories: files.map(f => ({ file: f.file, directory: f.dir })),
        total: files.length,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error('[api/history/local-files] ディレクトリ読み込みエラー:', error);
      res.json({
        success: true,
        files: [],
        total: 0,
        message: 'ローカルファイルディレクトリが見つかりません',
        timestamp: new Date().toISOString()
      });
    }
  } catch (error) {
    console.error('[api/history/local-files] ローカルファイル一覧取得エラー:', error);
    res.status(500).json({
      success: false,
      error: 'ローカルファイル一覧の取得に失敗しました',
      details: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// ローカルファイル内容取得API
app.get('/api/history/local-files/:filename', async (req, res) => {
  try {
    const { filename } = req.params;
    console.log('[api/history/local-files/:filename] ファイル内容取得リクエスト:', filename);
    
    const fs = require('fs').promises;
    const path = require('path');
    
    // セキュリティチェック: ファイル名に不正な文字が含まれていないかチェック
    if (filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
      return res.status(400).json({
        success: false,
        error: '不正なファイル名です',
        timestamp: new Date().toISOString()
      });
    }
    
    // 履歴ファイルを保存するディレクトリから検索（環境変数対応）
    const historyDir = process.env.LOCAL_HISTORY_DIR || path.join(__dirname, 'app-logs', 'history');
    const exportDir = process.env.LOCAL_EXPORT_DIR || path.join(__dirname, 'app-logs', 'exports');
    
    let filePath = null;
    
    // historyディレクトリから検索
    try {
      const historyPath = path.join(historyDir, filename);
      await fs.access(historyPath);
      filePath = historyPath;
    } catch (error) {
      // historyディレクトリにない場合、exportsディレクトリから検索
      try {
        const exportPath = path.join(exportDir, filename);
        await fs.access(exportPath);
        filePath = exportPath;
      } catch (error) {
        // どちらにもない場合
      }
    }
    
    if (!filePath) {
      return res.status(404).json({
        success: false,
        error: 'ファイルが見つかりません',
        filename: filename,
        timestamp: new Date().toISOString()
      });
    }
    
    // ファイル内容を読み込み
    const fileContent = await fs.readFile(filePath, 'utf8');
    const jsonData = JSON.parse(fileContent);
    
    console.log('[api/history/local-files/:filename] ファイル内容取得成功:', filename);
    
    res.json({
      success: true,
      filename: filename,
      content: jsonData,
      size: fileContent.length,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('[api/history/local-files/:filename] ファイル内容取得エラー:', error);
    res.status(500).json({
      success: false,
      error: 'ファイル内容の取得に失敗しました',
      details: error.message,
      filename: req.params.filename,
      timestamp: new Date().toISOString()
    });
  }
});

// エラーハンドリング
app.use((err, req, res, next) => {
  console.error('Server Error:', err);
  res.status(500).json({ 
    error: 'Internal Server Error',
    message: process.env.NODE_ENV === 'development' ? err.message : 'Something went wrong'
  });
});

// サーバー起動
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Emergency Assistance System running on port ${PORT}`);
  console.log(`📊 Environment: ${process.env.NODE_ENV || 'production'}`);
  console.log(`🌐 Frontend: http://localhost:${PORT}`);
  console.log(`🔗 API: http://localhost:${PORT}/api`);
  
  // runtime-config.jsを生成
  const runtimeConfig = {
    API_BASE_URL: '/api',  // 統合サーバーでは相対パスを使用
    CORS_ALLOW_ORIGINS: process.env.CORS_ALLOW_ORIGINS || '*',
    ENVIRONMENT: process.env.NODE_ENV || 'production'
  };
  
  const runtimeConfigContent = `window.runtimeConfig = ${JSON.stringify(runtimeConfig, null, 2)};`;
  
  try {
    fs.writeFileSync(path.join(__dirname, 'public', 'runtime-config.js'), runtimeConfigContent);
    console.log('✅ Runtime config generated');
  } catch (error) {
    console.error('❌ Failed to generate runtime config:', error);
  }
});

// グレースフルシャットダウン
process.on('SIGTERM', () => {
  console.log('🛑 SIGTERM received, shutting down gracefully');
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('🛑 SIGINT received, shutting down gracefully');
  process.exit(0);
});
