import express, { Request, Response } from 'express';
import session from 'express-session';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config(); // .env 読み込み（省略していた部分）

const app = express();

// CORS設定（フロントエンドからのリクエストを許可）
const allowedOrigins = [
  'http://localhost:3000',
  'http://localhost:4173', // Vite preview port
  'http://localhost:5001', // Vite dev port
  'http://127.0.0.1:3000',
  'http://127.0.0.1:4173',
  'http://127.0.0.1:5001'
];

// 環境変数で追加のオリジンが指定されている場合は追加
if (process.env.FRONTEND_URL) {
  allowedOrigins.push(process.env.FRONTEND_URL);
}

app.use(cors({
  origin: function (origin, callback) {
    // 開発環境では origin が null の場合も許可（Postman等からのリクエスト）
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      console.log('CORS blocked origin:', origin);
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Origin', 'Accept'],
  exposedHeaders: ['Set-Cookie']
}));

// JSONパース
app.use(express.json());

// セッション設定（セッションでログイン情報を保持）
app.use(session({
  secret: process.env.SESSION_SECRET || 'default-secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: false, // 本番では true に（HTTPSのみで送信されるようになる）
    maxAge: 1000 * 60 * 60 // 1時間
  }
}));

// ✅ ヘルスチェックAPI
app.get('/api/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// ✅ ダミーログインAPI（セッションに保存）
app.post('/api/auth/login', (req: Request, res: Response) => {
  req.session.user = {
    id: '123',
    name: 'テストユーザー'
  };
  res.json({ message: 'ログイン成功', user: req.session.user });
});

// ✅ ログイン中ユーザー取得API
app.get('/api/auth/user', (req: Request, res: Response) => {
  if (!req.session?.user) {
    return res.status(401).json({ error: '未ログイン' });
  }
  res.json(req.session.user);
});

// ✅ ログアウトAPI
app.post('/api/auth/logout', (req: Request, res: Response) => {
  req.session.destroy(err => {
    if (err) return res.status(500).json({ error: 'ログアウト失敗' });
    res.json({ message: 'ログアウトしました' });
  });
});

// 👇 サーバーを外部ファイルで起動する場合に備えて export
export default app;

