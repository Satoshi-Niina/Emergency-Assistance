import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import session from "express-session";
import bodyParser from "body-parser";
import { authRouter } from "./routes/auth";
import { emergencyGuideRouter } from "./routes/emergency-guide-router";
import { emergencyFlowRouter } from "./routes/emergency-flow";
import { flowGeneratorRouter } from "./routes/flow-generator";
import { registerChatRoutes } from "./routes/chat";
import { searchRouter } from "./routes/search";
import { registerDataProcessorRoutes } from "./routes/data-processor";
import { usersRouter } from "./routes/users";

import { techSupportRouter } from "./routes/tech-support";
import { syncRoutesRouter } from "./routes/sync-routes";
// import { databaseStorageRouter } from "./routes/database-storage";
import { createDefaultUsers } from "./scripts/create-default-users";
import { connectDB } from "./db";

dotenv.config({ path: "./server/.env" });

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(cors({ origin: true, credentials: true }));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(
  session({
    secret: process.env.SESSION_SECRET || "secret",
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false,
    },
  })
);

// Routes
app.use("/api/auth", authRouter);
app.use("/api/emergency-guides", emergencyGuideRouter);
app.use("/api/emergency-flows", emergencyFlowRouter);
app.use("/api/flow-generator", flowGeneratorRouter);
registerChatRoutes(app);
app.use("/api/search", searchRouter);
registerDataProcessorRoutes(app);
app.use("/api/users", usersRouter);

app.use("/api/tech-support", techSupportRouter);
app.use("/api/sync-routes", syncRoutesRouter);
// app.use("/api/database-storage", databaseStorageRouter);

// Health check
app.get("/api/health", (_, res) => {
  res.json({ status: "OK" });
});

// Start the server
app.listen(port, async () => {
  console.log(`🚀 Server listening on port ${port}`);
  
  // Try to connect to database (optional for development)
  try {
    await connectDB();
    await createDefaultUsers();
  } catch (err) {
    console.warn("⚠️ Database connection failed, but server is running:", err);
  }
});
