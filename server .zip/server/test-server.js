#!/usr/bin/env node

// Simple ESM test
import express from 'express';

const app = express();

app.get('/api/test', (req, res) => {
  res.json({ message: 'ESM test successful' });
});

app.listen(8000, () => {
  console.log('Test server running on port 8000');
});
