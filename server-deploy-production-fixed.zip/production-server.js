#!/usr/bin/env node

// Production-ready minimal server for Azure App Service v3
// JWT + PostgreSQL only, optimized for production deployment
// Force cache clear - updated timestamp: 2024-12-19

const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const session = require('express-session');
const { Pool } = require('pg');

// Environment validation
if (!process.env.JWT_SECRET) {
  console.error('❌ JWT_SECRET is required');
  process.exit(1);
}

// DATABASE_URL is required for production
if (!process.env.DATABASE_URL) {
  console.error('❌ DATABASE_URL is required for production deployment');
  process.exit(1);
}

// Initialize Express app
const app = express();

// Trust proxy for Azure App Service
app.set('trust proxy', 1);

// Middleware
app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  credentials: true
}));
app.use(express.json());

// Session configuration
app.use(session({
  secret: process.env.SESSION_SECRET || process.env.JWT_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000, // 24 hours
    sameSite: process.env.NODE_ENV === 'production' ? 'none' : 'lax'
  },
  name: 'sid'
}));

// Initialize PostgreSQL pool with SSL
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false }, // Azure PostgreSQL用
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

// Test database connection
pool.on('connect', () => {
  console.log('✅ Database connected');
});

pool.on('error', (err) => {
  console.error('❌ Database error:', err);
});

// JWT middleware with session fallback
const authenticateToken = (req, res, next) => {
  try {
    // JWT_SECRETの確認
    if (!process.env.JWT_SECRET) {
      console.error('[auth-middleware] JWT_SECRET not configured');
      return res.status(500).json({
        success: false,
        error: 'jwt_secret_not_configured',
        message: 'JWT設定が不完全です',
      });
    }

    // 診断ログ: 認証判定
    console.log('[auth-middleware] Auth check:', {
      hasAuthHeader: !!req.headers.authorization,
      hasSession: !!req.session?.userId,
      sessionId: req.session?.id,
      path: req.path,
      timestamp: new Date().toISOString(),
    });

    // Check for Bearer token first
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);

      try {
        const payload = jwt.verify(token, process.env.JWT_SECRET, {
          clockTolerance: 120, // ±120秒の時刻ずれを許容
        });

        // 詳細なJWT検証ログ
        console.log('[auth-middleware] JWT verification success:', {
          userId: payload.userId,
          username: payload.username,
          exp: payload.exp,
          currentTime: Math.floor(Date.now() / 1000),
        });

        req.user = { userId: payload.userId, username: payload.username };
        return next();
      } catch (jwtError) {
        // 詳細なJWTエラーログ
        console.warn('[auth-middleware] JWT verification failed:', {
          error: jwtError.name,
          message: jwtError.message,
          expiredAt: jwtError.expiredAt,
          currentTime: new Date().toISOString(),
        });

        // JWT無効の場合はセッション認証にフォールバック
      }
    }

    // Fallback to session authentication
    if (req.session?.userId) {
      req.user = { userId: req.session.userId, username: req.session.username };
      console.log('[auth-middleware] Session auth success:', {
        userId: req.session.userId,
        username: req.session.username,
      });
      return next();
    }

    // No valid authentication found
    console.log('[auth-middleware] No valid authentication found');
    return res.status(401).json({
      success: false,
      error: 'authentication_required',
      message: '認証が必要です',
      debug: {
        hasAuthHeader: !!req.headers.authorization,
        hasSession: !!req.session?.userId,
        sessionId: req.session?.id,
      },
    });
  } catch (error) {
    console.error('[auth-middleware] Authentication middleware error:', error);
    return res.status(500).json({
      success: false,
      error: 'authentication_error',
      message: '認証処理でエラーが発生しました',
    });
  }
};

// API Routes
const router = express.Router();

// Ping endpoint
router.get('/ping', (req, res) => {
  res.json({ success: true, message: 'pong', timestamp: new Date().toISOString() });
});

// Health check (DB independent) - GitHub Actions compatible
router.get('/health', (req, res) => {
  res.json({ 
    ok: true, 
    db: 'ok',
    status: 'healthy',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development'
  });
});

// Alternative health endpoint for GitHub Actions
router.get('/healthz', (req, res) => {
  res.json({ 
    ok: true, 
    db: 'ok',
    status: 'healthy',
    timestamp: new Date().toISOString()
  });
});

// Database readiness check - これが重要！
router.get('/readiness', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ ok: true, db: 'ready', timestamp: new Date().toISOString() });
  } catch (error) {
    console.error('Database readiness check failed:', error);
    res.status(503).json({ 
      ok: false, 
      db: 'error', 
      error: 'database_unavailable',
      timestamp: new Date().toISOString()
    });
  }
});

// Auth routes
router.post('/auth/login', async (req, res) => {
  try {
    // 診断ログ: リクエストヘッダー
    console.log('[auth/login] Request headers:', {
      authorization: req.headers.authorization ? '[SET]' : '[NOT SET]',
      cookie: req.headers.cookie ? '[SET]' : '[NOT SET]',
      host: req.headers.host,
      origin: req.headers.origin,
      'user-agent': req.headers['user-agent']?.substring(0, 50) + '...',
    });

    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ success: false, error: 'username_password_required' });
    }

    // Query user from database
    const result = await pool.query(
      'SELECT id, username, password FROM users WHERE username = $1 LIMIT 1',
      [username]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ success: false, error: 'invalid_credentials' });
    }

    const user = result.rows[0];

    // Verify password (assuming bcrypt)
    const bcrypt = require('bcrypt');
    const isValidPassword = await bcrypt.compare(password, user.password);

    if (!isValidPassword) {
      return res.status(401).json({ success: false, error: 'invalid_credentials' });
    }

    // Generate JWT token
    const token = jwt.sign(
      { userId: user.id, username: user.username },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    // Regenerate session to prevent session fixation
    req.session.regenerate((err) => {
      if (err) {
        console.error('[auth/login] Session regeneration error:', err);
        return res.status(500).json({ success: false, error: 'session_error' });
      }

      // Store user info in session
      req.session.userId = user.id;
      req.session.username = user.username;
      req.session.save((saveErr) => {
        if (saveErr) {
          console.error('[auth/login] Session save error:', saveErr);
          return res.status(500).json({ success: false, error: 'session_error' });
        }

        // 診断ログ: レスポンスヘッダー
        console.log('[auth/login] Response headers:', {
          'set-cookie': res.getHeader('set-cookie') ? '[SET]' : '[NOT SET]',
          sessionId: req.session.id,
        });

        res.json({
          success: true,
          accessToken: token,
          token: token,
          expiresIn: '24h',
          user: { id: user.id, username: user.username }
        });
      });
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ success: false, error: 'internal_server_error' });
  }
});

router.get('/auth/me', authenticateToken, (req, res) => {
  // 診断ログ: /me リクエスト
  console.log('[auth/me] Request headers:', {
    authorization: req.headers.authorization ? '[SET]' : '[NOT SET]',
    cookie: req.headers.cookie ? '[SET]' : '[NOT SET]',
    host: req.headers.host,
    origin: req.headers.origin,
  });
  console.log('[auth/me] Auth result:', {
    userId: req.user?.userId,
    sessionUserId: req.session?.userId,
    authMethod: req.headers.authorization ? 'Bearer' : 'Session',
  });

  res.json({
    authenticated: true,
    userId: req.user.userId,
    user: {
      id: req.user.userId,
      username: req.user.username
    }
  });
});

// Logout endpoint
router.post('/auth/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error('[auth/logout] Session destruction error:', err);
      return res.status(500).json({ success: false, error: 'logout_error' });
    }
    res.clearCookie('sid', { path: '/' });
    res.json({ success: true });
  });
});

// Handshake endpoint for frontend compatibility
router.get('/auth/handshake', (req, res) => {
  console.log('🔍 /api/auth/handshake 呼び出し');

  // 詳細なリクエスト情報をログ出力
  console.log('📊 Handshake request details:', {
    method: req.method,
    path: req.path,
    headers: {
      host: req.headers.host,
      'x-forwarded-for': req.headers['x-forwarded-for'],
      'x-forwarded-proto': req.headers['x-forwarded-proto'],
      'user-agent': req.headers['user-agent'],
      'content-type': req.headers['content-type'],
    },
    ip: req.ip,
    ips: req.ips,
    timestamp: new Date().toISOString(),
  });

  try {
    res.json({
      ok: true,
      mode: 'jwt',
      firstParty: !!process.env.COOKIE_DOMAIN,
      supportsToken: true,
      timestamp: new Date().toISOString(),
      environment: process.env.NODE_ENV || 'development',
      server: {
        port: process.env.PORT,
        trustProxy: req.app.get('trust proxy'),
        nodeVersion: process.version,
      },
    });
  } catch (error) {
    console.error('❌ /api/auth/handshake エラー:', error);
    console.error('❌ Stack trace:', error.stack);
    res.status(500).json({
      ok: false,
      error: 'handshake_failed',
      message: '握手エンドポイントでエラーが発生しました',
      timestamp: new Date().toISOString(),
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined,
    });
  }
});

// Root level endpoints for GitHub Actions compatibility (before API router)
app.get('/ping', (req, res) => {
  res.json({ success: true, message: 'pong', timestamp: new Date().toISOString() });
});

app.get('/health', (req, res) => {
  res.json({ 
    ok: true, 
    db: 'ok',
    status: 'healthy',
    timestamp: new Date().toISOString()
  });
});

app.get('/healthz', (req, res) => {
  res.json({ 
    ok: true, 
    db: 'ok',
    status: 'healthy',
    timestamp: new Date().toISOString()
  });
});

// Mount API router
app.use('/api', router);

// Global error handler (always JSON)
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  console.error('Error stack:', err.stack);
  console.error('Request details:', {
    method: req.method,
    url: req.url,
    headers: req.headers,
    body: req.body
  });
  res.status(500).json({
    success: false,
    error: 'internal_server_error',
    message: process.env.NODE_ENV === 'development' ? err.message : 'An error occurred',
    timestamp: new Date().toISOString()
  });
});

// 404 handler (always JSON)
app.use('*', (req, res) => {
  res.status(404).json({
    success: false,
    error: 'not_found',
    path: req.originalUrl
  });
});

// Start server
const PORT = Number(process.env.PORT?.trim() || '8000');
const HOST = '0.0.0.0';

app.listen(PORT, HOST, () => {
  console.log(`🚀 Server running on ${HOST}:${PORT}`);
  console.log(`📊 Health check: http://${HOST}:${PORT}/api/health`);
  console.log(`🔐 Login API: http://${HOST}:${PORT}/api/auth/login`);
  console.log(`📋 Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🔍 Database URL configured: ${process.env.DATABASE_URL ? 'YES' : 'NO'}`);
  console.log(`🔑 JWT Secret configured: ${process.env.JWT_SECRET ? 'YES' : 'NO'}`);
  console.log(`📁 Working directory: ${process.cwd()}`);
  console.log(`📄 Main file: ${__filename}`);
  console.log(`⏰ Start time: ${new Date().toISOString()}`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  pool.end(() => {
    console.log('Database pool closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  pool.end(() => {
    console.log('Database pool closed');
    process.exit(0);
  });
});
